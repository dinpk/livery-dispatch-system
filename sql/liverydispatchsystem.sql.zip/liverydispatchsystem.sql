-- phpMyAdmin SQL Dump
-- version 4.6.6deb5ubuntu0.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 06, 2022 at 08:32 PM
-- Server version: 5.7.38-0ubuntu0.18.04.1
-- PHP Version: 7.2.24-0ubuntu0.18.04.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `liverydispatchsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer_address_book`
--

CREATE TABLE `customer_address_book` (
  `key_customer_address_book` int(10) UNSIGNED NOT NULL,
  `key_customer_passengers` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `category` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer_billing_contacts`
--

CREATE TABLE `customer_billing_contacts` (
  `key_customer_billing_contacts` int(10) UNSIGNED NOT NULL,
  `contact_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `card_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `card_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `card_expiration` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `card_security_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name_on_card` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `confirmation_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_billing_contacts`
--

INSERT INTO `customer_billing_contacts` (`key_customer_billing_contacts`, `contact_name`, `card_type`, `card_number`, `card_expiration`, `card_security_code`, `name_on_card`, `address1`, `address2`, `city`, `state`, `country`, `zip_code`, `confirmation_email`, `phone`, `notes`, `active_status`, `entry_date_time`) VALUES
(1, 'Tresa Sweely', 'Bank of America', '1', '', '', 'Tresa Sweely', '22 Bridle Ln', '', 'Valley Park', 'Missouri', '', '63088', 'tresa_sweely@hotmail.com', '314-359-9566', '', 'on', '2022-06-01 16:26:13'),
(3, 'Kristeen Turinetti', 'Chase Bank', '2', '', '', 'Kristeen Turinetti', '70099 E North Ave', '', 'Arlington', 'Texas', '', '76013', 'kristeen@gmail.com', '817-213-8851', '', 'on', '2022-06-01 16:27:29'),
(4, 'Jenelle Regusters', 'Citibank', '3', '', '', 'Jenelle Regusters', '3211 E Northeast Loop', '', 'Tampa', 'Florida', '', '33619', 'jregusters@regusters.com', '813-932-8715', '', 'on', '2022-06-01 16:35:06'),
(5, 'Renea Monterrubio', 'Discover', '4', '', '', 'Renea Monterrubio', '26 Montgomery St', '', 'Atlanta', 'Georgia', '', '30328', 'renea@hotmail.com', '770-679-4752', '', 'on', '2022-06-01 16:35:49'),
(6, 'Olive Matuszak', 'Mastercard', '5', '', '', 'Olive Matuszak', '13252 Lighthouse Ave', '', 'Cathedral City', 'California', '', '92234', 'olive@aol.com', '760-938-6069', '', 'on', '2022-06-01 16:36:36'),
(7, 'Ligia Reiber', 'Visa', '6', '', '', 'Ligia Reiber', '206 Main St #2804', '', 'Lansing', 'Michigan', '', '48933', 'lreiber@cox.net', '517-906-1108', '', 'on', '2022-06-01 16:37:33'),
(8, 'Christiane Eschberger', 'Bank of America', '7', '', '', 'Christiane Eschberger', '96541 W Central Blvd', '', 'Phoenix', 'Arizona', '', '85034', 'christiane.eschberger@yahoo.com', '602-390-4944', '', 'on', '2022-06-01 16:38:14'),
(9, 'Goldie Schirpke', 'Chase Bank', '8', '', '', 'Goldie Schirpke', '34 Saint George Ave #2', '', 'Bangor', 'Maine', '', '04401', 'goldie.schirpke@yahoo.com', '207-295-7569', '', 'on', '2022-06-01 16:38:53'),
(10, 'Loreta Timenez', 'Citibank', '9', '', '', 'Loreta Timenez', '47857 Coney Island Ave', '', 'Clinton', 'Maryland', '', '20735', 'loreta.timenez@hotmail.com', '301-696-6420', '', 'on', '2022-06-01 16:39:27'),
(11, 'Fabiola Hauenstein', 'Citibank', '10', '', '', 'Fabiola Hauenstein', '8573 Lincoln Blvd', '', 'York', 'Pennsylvania', '', '17404', 'fabiola.hauenstein@hauenstein.org', '717-809-3119', '', 'on', '2022-06-01 16:39:59'),
(12, 'Amie Perigo', 'Mastercard', '11', '', '', 'Amie Perigo', '596 Santa Maria Ave #7913', '', 'Mesquite', 'Texas', '', '75150', 'amie.perigo@yahoo.com', '972-419-7946', '', 'on', '2022-06-01 16:40:31'),
(13, 'Raina Brachle', 'Visa', '12', '', '', 'Raina Brachle', '3829 Ventura Blvd', '', 'Butte', 'Montana', '', '59701', 'raina.brachle@brachle.org', '406-318-1515', '', 'on', '2022-06-01 16:41:08'),
(14, 'Erinn Canlas', 'Bank of America', '13', '', '', 'Erinn Canlas', '13 S Hacienda Dr', '', 'Livingston', 'New Jersey', '', '07039', 'erinn.canlas@canlas.com', '973-767-3008', '', 'on', '2022-06-01 16:41:44'),
(15, 'Cherry Lietz', 'Citibank', '14', '', '', 'Cherry Lietz', '40 9th Ave Sw #91', '', 'Waterford', 'Michigan', '', '48329', 'cherry@lietz.com', '248-980-6904', '', 'on', '2022-06-01 16:42:15'),
(16, 'Kattie Vonasek', 'Visa', '15', '', '', 'Kattie Vonasek', '2845 Boulder Crescent St', '', 'Cleveland', 'Ohio', '', '44103', 'kattie@vonasek.org', '216-923-3715', '', 'on', '2022-06-01 16:42:47'),
(19, 'Brock Bolognia', 'Discover', '20', '', '', 'Brock Bolognia', '4486 W O St #1', '', 'New York', 'New York', '', '10003', 'bbolognia@yahoo.com', '212-402-9216', '', 'on', '2022-06-04 16:08:50'),
(20, 'Lorrie Nestle', 'Bank of America', '123456', '', '', 'Lorrie Nestle', '39 S 7th St', '', 'Tullahoma', 'Tennessee', '', '37388', 'lnestle@hotmail.com', '931-875-6644', '', 'on', '2022-06-05 14:56:31'),
(21, 'Sabra Uyetake', 'Bank of America', '1234567', '', '', 'Sabra Uyetake', '98839 Hawthorne Blvd #6101', '', 'Columbia', 'South Carolina', 'United States', '29201', 'sabra@uyetake.org', '803-925-5213', '', 'on', '2022-06-05 15:10:54'),
(22, 'Karl Klonowski', 'Mastercard', '12345678', '', '', 'Karl Klonowski', '76 Brooks St #9', '', 'Flemington', 'New Jersey', 'United States', '08822', 'karl_klonowski@yahoo.com', '908-877-6135', '', 'on', '2022-06-06 13:34:31'),
(23, 'Tonette Wenner', 'Citibank', '123456789', '', '', 'Tonette Wenner', '4545 Courthouse Rd', '', 'Westbury', 'New York', 'United States', '11590', 'twenner@aol.com', '516-968-6051', '', 'on', '2022-06-06 14:13:39'),
(24, 'Amber Monarrez', 'Bank of America', '564654858418', '', '', 'Amber Monarrez', '14288 Foster Ave #4121', '', 'Jenkintown', '', 'United States', '19046', 'amber_monarrez@monarrez.org', '215-934-8655', '', 'on', '2022-06-06 14:32:04'),
(25, 'Shenika Seewald', 'Bank of America', '5348633513843', '', '', 'Shenika Seewald', '4 Otis St', '', 'Van Nuys', '', 'United States', '91405', 'shenika@gmail.com', '818-423-4007', '', 'on', '2022-06-06 14:49:58'),
(26, 'Delmy Ahle', 'Bank of America', '56465753486', '', '', 'Delmy Ahle', '65895 S 16th St', '', 'Providence', '', 'United States', '02909', 'dmyahlu@gmail.com', '401-458-2547', '', 'on', '2022-06-06 14:54:27'),
(27, 'Maurine Yglesias', 'Bank of America', '5645648645', '', '', 'Maurine Yglesias', '59 Shady Ln #53', '', 'Milwaukee', 'Wisconsin', 'United States', '53214', 'maurine_yglesias@yglesias.com', '414-748-1374', '', 'on', '2022-06-06 15:20:11'),
(28, 'Tawna Buvens', 'Bank of America', '567648646', '', '', 'Tawna Buvens', '3305 Nabell Ave #679', '', 'New York', 'New York', 'United States', '10009', 'tawnabuvens@yahoo.com', '212-674-9610', '', 'on', '2022-06-06 15:28:07'),
(29, 'Elly Morocco', 'Discover', '6546878646', '', '', 'Elly Morocco', '7 W 32nd St', '', 'Erie', 'Pennsylvania', 'United States', '16502', 'ellymorocco@live.com', '814-393-5571', '', 'on', '2022-06-06 15:31:21');

-- --------------------------------------------------------

--
-- Table structure for table `customer_companies`
--

CREATE TABLE `customer_companies` (
  `key_customer_companies` int(10) UNSIGNED NOT NULL,
  `company_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone1` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone2` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `website` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_companies`
--

INSERT INTO `customer_companies` (`key_customer_companies`, `company_name`, `address1`, `address2`, `city`, `state`, `zip_code`, `phone1`, `phone2`, `email`, `website`, `country`, `image_url`, `notes`, `active_status`, `entry_date_time`) VALUES
(1, 'North Central Council', '2184 Worth St', '', 'Hayward', 'California', '94545', '314-359-9566', '314-231-3514', 'info@northcentralcouncil.com', 'http://www.northcentralcouncil.com', 'United States', '', '', 'on', '2022-05-27 16:17:28'),
(2, 'Fiorucci Foods', '50126 N Plankinton Ave', '', 'Longwood', 'Florida', '32750', '407-538-5106', '407-564-8113', 'shawnda.yori@yahoo.com', 'http://www.fioruccifoodsusainc.com', 'United States', '', '', 'on', '2022-05-27 17:46:41'),
(3, 'Sign All', '38773 Gravois Ave', '', 'Cheyenne', 'Wyoming', '82001', '307-403-1488', '307-816-7115', 'mdelasancha@hotmail.com', 'http://www.signall.com', 'United States', '', '', 'on', '2022-05-27 17:47:20'),
(4, 'Sammys Steak', '16452 Greenwich St.', '', 'Garden City', 'New York', '11530', '516-393-9967', '516-407-9573', 'gilma_liukko@gmail.com', 'http://www.sammyssteakden.com', 'United States', '', '', 'on', '2022-05-27 17:47:59'),
(5, 'Morgan Custom Homes', '20113 4th Ave E', '', 'Kearny', 'New Jersey', '07032', '201-431-2989', '201-478-8540', 'lili.paskin@cox.net', 'http://www.morgancustomhomes.com', 'United States', '', '', 'on', '2022-05-27 17:48:47'),
(6, 'Olsen Payne & Company', '6 Ridgewood Center Dr', '', 'Old Forge', 'Pennsylvania', '18518', '570-648-3035', '570-569-2356', 'loren.asar@aol.com', 'http://www.olsenpaynecompany.com', 'United States', '', '', 'on', '2022-05-27 17:49:26'),
(7, 'Cowan & Kelly', '469 Outwater Ln', '', 'San Diego', 'California', '92126', '858-617-7834', '858-732-1884', 'dorothy@cox.net', 'http://www.cowankelly.com', 'United States', '', '', 'on', '2022-05-27 17:49:58'),
(8, 'Jen Pharmaceuticals', '3338 A Lockport Pl #6', '', 'Margate City', 'New Jersey', '08402', '609-373-3332', '609-826-4990', 'catalina@hotmail.com', 'http://www.jenpharmaceuticalsinc.com', 'United States', '', '', 'on', '2022-05-27 17:50:51'),
(9, 'New England Security Equipment', '9 Hwy', '', 'Providence', 'Rhode Island', '02906', '401-465-6432', '401-893-1820', 'lawrence.lorens@hotmail.com', 'http://www.newenglandsecequipcoinc.com', 'United States', '', '', 'on', '2022-05-27 17:51:29'),
(10, 'ATC Contracting', '5 Washington St #1', '', 'Roseville', 'California', '95678', '916-920-3571', '916-459-2433', 'tankeny@ankeny.org', 'http://www.atccontracting.com', 'United States', '', '', 'on', '2022-05-27 17:52:10'),
(11, 'Kwikprint', '9 Front St', '', 'Washington', 'District of Columbia', '20001', '202-646-7516', '202-276-6826', 'alesia_hixenbaugh@hixenbaugh.org', 'http://www.kwikprint.com', 'United States', '', '', 'on', '2022-05-27 17:52:45'),
(12, 'Buergi & Madden Scale', '1933 Packer Ave #2', '', 'Novato', 'California', '94945', '415-423-3294', '415-926-6089', 'info@buergimaddenscale.com', 'http://www.buergimaddenscale.com', 'United States', '', '', 'on', '2022-05-27 17:53:35'),
(13, 'Inner Label', '67 Rv Cent', '', 'Boise', 'Idaho', '83709', '208-709-1235', '208-206-9848', 'bgillaspie@gillaspie.com', 'http://www.innerlabel.com', 'United States', '', '', 'on', '2022-05-27 17:54:09'),
(14, 'Hermar Corporation', '2 Sw Nyberg Rd.', '', 'Elkhart', 'Indiana', '46514', '574-499-1454', '574-330-1884', 'rkampa@kampa.org', 'http://www.hermarinc.com', 'United States', '', '', 'on', '2022-05-27 17:54:51'),
(15, 'Warehouse Office & Paper Products', '61556 W 20th Ave', '', 'Seattle', 'Washington', '98104', '206-711-6498', '206-395-6284', 'jbiddy@yahoo.com', 'http://www.warehouseofficepaperprod.com', 'United States', '', '', 'on', '2022-05-27 17:55:27'),
(16, 'Travelodge', '63 E Aurora Dr', '', 'Orlando', 'Florida', '32804', '407-413-4842', '407-557-8857', 'chauncey_motley@aol.com', 'http://www.travelodgeinc.com', 'United States', '', '', 'on', '2022-05-27 17:56:28');

-- --------------------------------------------------------

--
-- Table structure for table `customer_contacts`
--

CREATE TABLE `customer_contacts` (
  `key_customer_contacts` int(10) UNSIGNED NOT NULL,
  `company_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `key_customer_companies` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `image_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_phone_extension` int(10) NOT NULL DEFAULT '0',
  `mobile_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_contacts`
--

INSERT INTO `customer_contacts` (`key_customer_contacts`, `company_name`, `key_customer_companies`, `image_url`, `first_name`, `last_name`, `address1`, `address2`, `city`, `state`, `zip_code`, `country`, `work_phone`, `work_phone_extension`, `mobile_phone`, `email`, `active_status`, `entry_date_time`) VALUES
(1, 'ATC Contracting', 10, '', 'Micaela', 'Rhymes', '20932 Hedley St.', '', 'Concord', 'California', '94520', 'United States', '925-647-3298', 149, '925-522-7798', 'micaela_rhymes@gmail.com', 'on', '2022-05-28 15:10:03'),
(2, 'North Central Council', 1, '', 'Tamar', 'Hoogland', '2737 Pistorio Rd #9230', '', 'London', '', '43140', 'United States', '740-343-8575', 24, '740-526-5410', 'tamar@hotmail.com', 'on', '2022-05-28 15:16:18'),
(3, 'Fiorucci Foods', 2, '', 'Moon', 'Parlato', '74989 Brandon St', '', 'Wellsville', 'New York', '14895', 'United States', '585-866-8313', 45, '585-498-4278', 'moon@yahoo.com', 'on', '2022-05-28 15:17:39'),
(4, 'Sign All', 3, '', 'Laurel', 'Reitler', '6 Kains Ave', '', 'Baltimore', 'Maryland', '21215', 'United States', '410-957-6903', 21, '410-957-6903', 'laurel_reitler@reitler.com', 'on', '2022-05-28 15:19:09'),
(5, 'Sammys Steak', 4, '', 'Sign All', 'Crupi', '47565 W Grand Ave', '', 'Newark', 'New Jersey', '07105', 'United States', '973-354-2040', 18, '973-847-9611', 'delisa.crupi@crupi.com', 'on', '2022-05-28 15:20:12'),
(6, 'Morgan Custom Homes', 5, '', 'Viva', 'Toelkes', '4284 Dorigo Ln', '', 'Chicago', '', '60647', 'United States', '773-446-5569', 35, '773-352-3437', 'viva.toelkes@gmail.com', 'on', '2022-05-28 17:34:57'),
(7, 'Olsen Payne & Company', 6, '', 'Elza', 'Lipke', '6794 Lake Dr E', '', 'Newark', 'New Jersey', '07104', 'United States', '973-927-3447', 17, '973-796-3667', 'elza@yahoo.com', 'on', '2022-05-28 17:35:47'),
(8, 'Cowan & Kelly', 7, '', 'Devorah', 'Chickering', '31 Douglas Blvd #950', '', 'Clovis', 'New Mexico', '88101', 'United States', '505-975-8559', 15, '505-950-1763', 'devorah@hotmail.com', 'on', '2022-05-28 17:36:43'),
(9, 'Jen Pharmaceuticals', 8, '', 'Timothy', 'Mulqueen', '44 W 4th St', '', 'Staten Island', 'New York', '10309', 'United States', '718-332-6527', 20, '718-654-7063', 'timothy_mulqueen@mulqueen.org', 'on', '2022-05-28 17:40:50'),
(10, 'New England Security Equipment', 9, '', 'Arlette', 'Honeywell', '11279 Loytan St', '', 'Jacksonville', 'Florida', '32254', 'United States', '904-775-4480', 13, '904-514-9918', 'ahoneywell@honeywell.com', 'on', '2022-05-28 17:42:50'),
(11, 'Kwikprint', 11, '', 'Dominque', 'Dickerson', '69 Marquette Ave', '', 'Hayward', 'California', '94545', 'United States', '510-993-3758', 23, '510-901-7640', 'dominque.dickerson@dickerson.org', 'on', '2022-05-28 17:43:37'),
(12, 'Buergi & Madden Scale', 12, '', 'Lettie', 'Isenhower', '70 W Main St', '', 'Beachwood', 'Ohio', '44122', 'United States', '216-657-7668	216-733-8494', 24, '216-733-8494', 'lettie_isenhower@yahoo.com', 'on', '2022-05-28 17:44:28'),
(13, 'Inner Label', 13, '', 'Myra', 'Munns', '461 Prospect Pl #316', '', 'Euless', 'Texas', '76040', 'United States', '817-914-7518', 12, '817-451-3518', 'mmunns@cox.net', 'on', '2022-05-28 17:45:18'),
(14, 'Warehouse Office & Paper Products', 15, '', 'Stephaine', 'Barfield', '47154 Whipple Ave Nw', '', 'Gardena', 'California', '90247', 'United States', '310-774-7643', 34, '310-968-1219', 'stephaine@barfield.com', 'on', '2022-05-28 17:46:05');

-- --------------------------------------------------------

--
-- Table structure for table `customer_invoices`
--

CREATE TABLE `customer_invoices` (
  `key_customer_invoices` int(10) UNSIGNED NOT NULL,
  `key_customer_passengers` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `amount` float NOT NULL DEFAULT '0',
  `amount_paid` float NOT NULL DEFAULT '0',
  `payment_method` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `due_date` date DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer_passengers`
--

CREATE TABLE `customer_passengers` (
  `key_customer_passengers` int(10) UNSIGNED NOT NULL,
  `key_customer_companies` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_customer_rate_packages` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_customer_billing_contacts` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `first_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_phone_extension` int(10) NOT NULL DEFAULT '0',
  `mobile_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `website` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `company_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `package_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `billing_contact_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payment_method` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `confirm_to_passenger` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `confirm_to_contact` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `confirm_to_billing_contact` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `trip_ticket_notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ad_source` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_passengers`
--

INSERT INTO `customer_passengers` (`key_customer_passengers`, `key_customer_companies`, `key_customer_rate_packages`, `key_customer_billing_contacts`, `first_name`, `last_name`, `address1`, `address2`, `city`, `state`, `country`, `zip_code`, `work_phone`, `work_phone_extension`, `mobile_phone`, `email`, `website`, `image_url`, `company_name`, `package_name`, `billing_contact_name`, `payment_method`, `confirm_to_passenger`, `confirm_to_contact`, `confirm_to_billing_contact`, `notes`, `trip_ticket_notes`, `ad_source`, `active_status`, `entry_date_time`) VALUES
(1, 1, 1, 10, 'Blair', 'Malet', '209 Decker Dr', '', 'Philadelphia', 'Pennsylvania', 'United States', '19132', '215-907-9111', 12, '215-794-4519', 'bmalet@yahoo.com', 'http://www.bollingermachshpshipyard.com', '', 'North Central Council', 'Regular', 'Loreta Timenez', 'Credit card', 'on', 'on', 'on', '', '', 'Social media', 'on', '2022-06-04 14:40:32'),
(2, 2, 2, 19, 'Brock', 'Bolognia', '4486 W O St #1', '', 'New York', 'New York', 'United States', '10003', '212-402-9216', 0, '212-617-5063', 'bbolognia@yahoo.com', 'http://www.orindanews.com', '', 'Fiorucci Foods', 'Concession', 'Brock Bolognia', 'Credit card', 'on', '', '', '', '', 'Referral', 'on', '2022-06-04 16:09:16'),
(3, 3, 3, 20, 'Lorrie', 'Nestle', '39 S 7th St', '', 'Tullahoma', 'Tennessee', 'United States', '37388', '931-875-6644', 0, '931-303-6041', 'lnestle@hotmail.com', 'http://www.ballardspahrandrews.com', '', 'Sign All', 'Swift', 'Lorrie Nestle', 'Cash', 'on', 'on', 'on', '', '', 'Print media', 'on', '2022-06-05 15:09:39'),
(4, 4, 1, 21, 'Sabra', 'Uyetake', '98839 Hawthorne Blvd #6101', '', 'Columbia', 'South Carolina', 'United States', '29201', '803-925-5213', 0, '803-681-3678', 'sabra@uyetake.org', 'http://www.lowylimousineservice.com', '', 'Sammys Steak', 'Regular', 'Sabra Uyetake', 'Cash', 'on', 'on', 'on', '', '', 'Radio', 'on', '2022-06-05 15:10:58'),
(5, 5, 1, 13, 'Marjory', 'Mastella', '71 San Mateo Ave', '', 'Wayne', 'Pennsylvania', 'United States', '19087', '610-814-5533', 0, '610-379-7125', 'mmastella@mastella.com', 'http://www.viconcorporation.com', '', 'Morgan Custom Homes', 'Regular', 'Raina Brachle', 'Electronic bank transfer', 'on', '', '', '', '', 'Film', 'on', '2022-06-05 16:06:31'),
(6, 5, 4, 22, 'Karl', 'Klonowski', '76 Brooks St #9', '', 'Flemington', 'New Jersey', 'United States', '08822', '908-877-6135', 0, '908-470-4661', 'karl_klonowski@yahoo.com', 'http://www.rossimichaelm.com', '', 'Morgan Custom Homes', 'Express', 'Karl Klonowski', 'Credit card', 'on', '', '', '', '', 'Television', 'on', '2022-06-06 13:34:41'),
(7, 6, 1, 23, 'Tonette', 'Wenner', '4545 Courthouse Rd', '', 'Westbury', 'New York', 'United States', '11590', '516-968-6051', 0, '516-333-4861', 'twenner@aol.com', 'http://www.northwestpublishing.com', '', 'Olsen Payne & Company', 'Regular', 'Tonette Wenner', 'Cash', 'on', '', '', '', '', 'Direct mail', 'on', '2022-06-06 14:13:43'),
(8, 7, 1, 24, 'Amber', 'Monarrez', '14288 Foster Ave #4121', '', 'Jenkintown', 'Pennsylvania', 'United States', '19046', '215-934-8655', 0, '215-329-6386', 'amber_monarrez@monarrez.org', 'http://www.branfordwiremfgco.com', '', 'Cowan & Kelly', 'Regular', 'Amber Monarrez', 'Credit card', 'on', '', '', '', '', 'Email marketing', 'on', '2022-06-06 14:32:19'),
(9, 8, 2, 25, 'Shenika', 'Seewald', '4 Otis St', '', 'Van Nuys', 'California', 'United States', '91405', '818-423-4007', 0, '818-749-8650', 'shenika@gmail.com', 'http://www.eastcoastmarketing.com', '', 'Jen Pharmaceuticals', 'Concession', 'Shenika Seewald', 'Debit card', 'on', '', '', '', '', 'Social media', 'on', '2022-06-06 14:50:07'),
(10, 9, 1, 26, 'Delmy', 'Ahle', '65895 S 16th St', '', 'Providence', 'Rhode Island', 'United States', '02909', '401-458-2547', 0, '401-559-8961', 'delmy.ahle@hotmail.com', 'http://www.wyetechnologiesinc.com', '', 'New England Security Equipment', 'Regular', 'Delmy Ahle', 'Credit card', '', '', 'on', '', '', 'Print media', 'on', '2022-06-06 14:54:34'),
(11, 10, 1, 0, 'Deeanna', 'Juhas', '14302 Pennsylvania Ave', '', 'Huntingdon Valley', 'Pennsylvania', 'United States', '19006', '215-211-9589', 0, '215-417-9563', 'deeanna_juhas@gmail.com', 'http://www.healygeorgewiv.com', '', 'ATC Contracting', 'Regular', '', 'Cash', 'on', '', '', '', '', 'Referral', 'on', '2022-06-06 14:56:41'),
(12, 11, 3, 0, 'Blondell', 'Pugh', '201 Hawk Ct', '', 'Providence', 'Rhode Island', 'United States', '02904', '401-960-8259', 0, '401-300-8122', 'bpugh@aol.com', 'http://www.alpenliteinc.com', '', 'Kwikprint', 'Swift', '', 'Check', 'on', '', '', '', '', 'Direct mail', 'on', '2022-06-06 14:58:02'),
(13, 12, 1, 0, 'Jamal', 'Vanausdal', '53075 Sw 152nd Ter #615', '', 'Monroe Township', 'New Jersey', 'United States', '08831', '732-234-1546', 0, '732-904-2931', 'jamal@vanausdal.org', 'http://www.hubbardbruceesq.com', '', 'Buergi & Madden Scale', 'Regular', '', 'Check', 'on', '', '', '', '', 'Radio', 'on', '2022-06-06 14:59:17'),
(14, 13, 4, 0, 'Cecily', 'Hollack', '59 N Groesbeck Hwy', '', 'Austin', 'Texas', 'United States', '78731', '512-486-3817', 0, '512-861-3814', 'cecily@hollack.org', 'http://www.arthuraoliversoninc.com', '', 'Inner Label', 'Express', '', 'Cash', 'on', '', '', '', '', 'Direct mail', 'on', '2022-06-06 15:00:14'),
(15, 14, 1, 0, 'Carmelina', 'Lindall', '2664 Lewis Rd', '', 'Littleton', 'Colorado', 'United States', '80126', '303-724-7371', 0, '303-874-5160', 'carmelina_lindall@lindall.com', 'http://www.georgejessopcarterjewelers.com', '', 'Hermar Corporation', 'Regular', '', 'Check', 'on', '', '', '', '', 'Film', 'on', '2022-06-06 15:01:17'),
(16, 15, 1, 27, 'Maurine', 'Yglesias', '59 Shady Ln #53', '', 'Milwaukee', 'Wisconsin', 'United States', '53214', '414-748-1374', 0, '414-573-7719', 'maurine_yglesias@yglesias.com', 'http://www.schultzthomascmd.com', '', 'Warehouse Office & Paper Products', 'Regular', 'Maurine Yglesias', 'Credit card', 'on', '', '', '', '', 'Billboard', 'on', '2022-06-06 15:20:14'),
(17, 16, 2, 28, 'Tawna', 'Buvens', '3305 Nabell Ave #679', '', 'New York', 'New York', 'United States', '10009', '212-674-9610', 0, '212-462-9157', 'tawna@gmail.com', 'http://www.hhhenterprisesinc.com', '', 'Travelodge', 'Concession', 'Tawna Buvens', 'Debit card', '', '', 'on', '', '', 'Social media', 'on', '2022-06-06 15:28:14'),
(18, 1, 1, 0, 'Penney', 'Weight', '18 Fountain St', '', 'Anchorage', 'Alaska', 'United States', '99515', '907-797-9628', 0, '907-873-2882', 'penney_weight@aol.com', 'http://www.hawaiiankinghotel.com', '', 'North Central Council', 'Regular', '', 'Cash', 'on', '', '', '', '', 'Referral', 'on', '2022-06-06 15:29:58'),
(19, 2, 1, 29, 'Elly', 'Morocco', '7 W 32nd St', '', 'Erie', 'Pennsylvania', 'United States', '16502', '814-393-5571', 0, '814-420-3553', 'elly_morocco@gmail.com', 'http://www.killionindustries.com', '', 'Fiorucci Foods', 'Regular', 'Elly Morocco', 'Debit card', '', '', 'on', '', '', 'Email marketing', 'on', '2022-06-06 15:31:29');

-- --------------------------------------------------------

--
-- Table structure for table `customer_rate_packages`
--

CREATE TABLE `customer_rate_packages` (
  `key_customer_rate_packages` int(10) UNSIGNED NOT NULL,
  `package_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `gratuity_percent` float NOT NULL DEFAULT '0',
  `gas_surcharge_percent` float NOT NULL DEFAULT '0',
  `admin_fee_percent` float NOT NULL DEFAULT '0',
  `discount_percent` float NOT NULL DEFAULT '0',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_rate_packages`
--

INSERT INTO `customer_rate_packages` (`key_customer_rate_packages`, `package_name`, `gratuity_percent`, `gas_surcharge_percent`, `admin_fee_percent`, `discount_percent`, `entry_date_time`) VALUES
(1, 'Regular', 20, 0, 0, 0, '2022-06-04 14:27:45'),
(2, 'Concession', 20, 0, 0, 5, '2022-06-04 14:31:07'),
(3, 'Swift', 20, 6, 0, 0, '2022-06-04 14:32:54'),
(4, 'Express', 20, 7, 10, 0, '2022-06-04 14:33:21');

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `key_drivers` int(10) UNSIGNED NOT NULL,
  `key_vehicles` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `image_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contract_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_phone_extension` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mobile_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date_of_birth` date DEFAULT NULL,
  `license_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `license_expiry_date` date DEFAULT NULL,
  `social_security_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `hire_date` date DEFAULT NULL,
  `fleet_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payment_method` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `base_amount_percent` float NOT NULL DEFAULT '0',
  `pay_gratuity_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `gratuity_percent` float NOT NULL DEFAULT '0',
  `pay_commission_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `commission_percent` float NOT NULL DEFAULT '0',
  `pay_extra_stops_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extra_stops_percent` float NOT NULL DEFAULT '0',
  `pay_offtime_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `offtime_percent` float NOT NULL DEFAULT '0',
  `pay_tolls_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tolls_percent` float NOT NULL DEFAULT '0',
  `pay_parking_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `parking_percent` float NOT NULL DEFAULT '0',
  `pay_gas_surcharge_checkbox` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `gas_surcharge_percent` float NOT NULL DEFAULT '0',
  `pay_extra_charges_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extra_charges_percent` float NOT NULL DEFAULT '0',
  `notes` varchar(3000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `drivers`
--

INSERT INTO `drivers` (`key_drivers`, `key_vehicles`, `image_url`, `username`, `password`, `first_name`, `last_name`, `contract_type`, `address1`, `address2`, `city`, `state`, `zip_code`, `work_phone`, `work_phone_extension`, `mobile_phone`, `email`, `date_of_birth`, `license_number`, `license_expiry_date`, `social_security_number`, `hire_date`, `fleet_number`, `payment_method`, `base_amount_percent`, `pay_gratuity_checkbox`, `gratuity_percent`, `pay_commission_checkbox`, `commission_percent`, `pay_extra_stops_checkbox`, `extra_stops_percent`, `pay_offtime_checkbox`, `offtime_percent`, `pay_tolls_checkbox`, `tolls_percent`, `pay_parking_checkbox`, `parking_percent`, `pay_gas_surcharge_checkbox`, `gas_surcharge_percent`, `pay_extra_charges_checkbox`, `extra_charges_percent`, `notes`, `active_status`, `entry_date_time`) VALUES
(3001, 1002, 'https://i.ibb.co/Hh39WPQ/628285-avatar-blond-female-girl-person-icon.png', 'tyrashields', '1234567', 'Tyra', 'Shields', 'Employee', '3 Fort Worth Ave', '', 'Fairfax', 'Virginia', '22106', '703-255-1641', '', '703-228-8264', 'tshields@gmail.com', '1998-02-08', 'T54821457', '2025-05-05', '110-10-1145', '2015-03-15', 'Sedan (F1235)', '', 100, 'on', 100, 'on', 0, 'on', 100, 'on', 100, 'on', 100, 'on', 100, 'on', 100, 'on', 100, '', 'on', '2022-05-18 16:57:41'),
(3002, 1001, 'https://i.ibb.co/ftbxGz2/628289-avatar-business-costume-male-man-icon.png', 'tammara', '123456', 'Tammara', 'Wardrip', 'Employee', '4800 Black Horse Pike', '', 'Silver Spring', 'Maryland', '21015', '301-803-1936', '', '301-216-5075', 'twardrip@cox.net', '1995-12-18', 'T57493548', '2025-07-12', '680-84-2824', '2018-04-15', 'SUV (F1234)', '', 100, 'on', 100, 'on', 0, 'on', 100, 'on', 100, 'on', 100, 'on', 100, 'on', 100, 'on', 100, '', 'on', '2022-05-21 15:23:11'),
(3003, 1003, '', 'corygibes', '123456', 'Cory', 'Gibes', 'Employee', '83649 W Belmont Ave', '', 'Washington', 'District of Columbia', '20154', '202-572-1096', '', '202-696-2777', 'cory.gibes@gmail.com', '2001-12-24', 'T95159647', '2024-11-19', '647-54-1179', '2020-06-05', 'Sedan (F1236)', '', 100, 'on', 100, 'on', 0, 'on', 100, 'on', 100, 'on', 100, 'on', 100, 'on', 100, 'on', 100, '', 'on', '2022-05-21 15:30:50'),
(3004, 1007, '', 'danica', '123456', 'Danica', 'Bruschke', 'Contractor', '840 15th Ave', '', 'Arlington', 'Virginia', '22424', '703-782-8569', '', '703-205-1422', 'danica_bruschke@gmail.com', '1990-03-26', 'T58473951', '2025-08-08', '745-14-9657', '2019-01-22', 'SUV (F1240)', '', 100, 'on', 100, 'on', 0, 'on', 100, 'on', 100, 'on', 100, 'on', 100, 'on', 100, 'on', 100, '', 'on', '2022-05-21 15:34:55'),
(3005, 1006, '', 'wilda', '123456', 'Wilda', 'Giguere', 'Contractor', '1747 Calle Amanecer #2', '', 'Baltimore', 'Maryland', '21484', '301-870-5536', '', '301-914-9482', 'wilda@cox.net', '1998-04-17', 'T65789134', '2025-03-08', '743-49-6492', '2018-09-07', 'Van (F1239)', '', 100, 'on', 100, 'on', 0, 'on', 100, 'on', 100, 'on', 100, 'on', 100, 'on', 100, 'on', 100, '', 'on', '2022-05-21 15:37:07'),
(3006, 1005, '', 'carma', '123456', 'Carma', 'Vanheusen', 'Employee', '68556 Central Hwy', '', 'Springfield', 'Virginia', '22348', '703-503-7169', '', '703-452-4835', 'carma@cox.net', '2003-05-14', 'T71957617', '2024-09-07', '348-74-6547', '2020-05-09', 'Van (F1238)', '', 100, 'on', 100, 'on', 0, 'on', 100, 'on', 100, 'on', 100, 'on', 100, 'on', 100, 'on', 100, '', 'on', '2022-05-21 15:39:05'),
(3007, 1004, '', 'malinda', '123456', 'Malinda', 'Hochard', 'Contractor', '55 Riverside Ave', '', 'Fort Washington', 'Maryland', '21154', '301-722-5066', '', '301-472-2412', 'malinda.hochard@yahoo.com', '1997-02-28', 'T65172158', '2024-06-08', '957-14-9637', '2020-09-07', 'Sedan (F1237)', '', 100, 'on', 100, 'on', 0, 'on', 100, 'on', 100, 'on', 100, 'on', 100, 'on', 100, 'on', 100, '', 'on', '2022-05-21 15:40:50');

-- --------------------------------------------------------

--
-- Table structure for table `driver_payroll`
--

CREATE TABLE `driver_payroll` (
  `key_driver_payroll` int(10) UNSIGNED NOT NULL,
  `key_drivers` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `amount` float NOT NULL DEFAULT '0',
  `amount_paid` float NOT NULL DEFAULT '0',
  `payment_method` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `due_date` date DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `landmarks`
--

CREATE TABLE `landmarks` (
  `key_landmarks` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `category` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notes` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `key_logs` int(10) UNSIGNED NOT NULL,
  `log_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `log_datetime` datetime DEFAULT CURRENT_TIMESTAMP,
  `action_performed` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rates_zones`
--

CREATE TABLE `rates_zones` (
  `key_rates_zones` int(10) UNSIGNED NOT NULL,
  `from_city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `from_state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `rate` float NOT NULL DEFAULT '0',
  `tolls` float NOT NULL DEFAULT '0',
  `miles` float NOT NULL DEFAULT '0',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `rates_zones`
--

INSERT INTO `rates_zones` (`key_rates_zones`, `from_city`, `from_state`, `to_city`, `to_state`, `rate`, `tolls`, `miles`, `active_status`, `entry_date_time`) VALUES
(1, 'BWI', 'Maryland', 'Loudoun', 'Virginia', 228, 0, 76, 'on', '2022-05-15 09:36:29'),
(2, 'Loudoun', 'Virginia', 'BWI', 'Virginia', 228, 0, 76, 'on', '2022-05-15 09:36:29'),
(3, 'IAD', 'Virginia', 'BWI', 'Maryland', 175, 0, 58.2, 'on', '2022-05-15 09:51:23'),
(4, 'BWI', 'Maryland', 'IAD', 'Virginia', 175, 0, 58.2, 'on', '2022-05-15 09:51:23'),
(5, 'Alexandria', 'Virginia', 'Loudoun', 'Virginia', 154, 0, 51.4, 'on', '2022-05-15 09:53:06'),
(6, 'Loudoun', 'Virginia', 'Alexandria', 'Virginia', 154, 0, 51.4, 'on', '2022-05-15 09:53:06'),
(7, 'BWI', 'Maryland', 'Falls Church', 'Virginia', 149, 0, 49.6, 'on', '2022-05-15 09:53:44'),
(8, 'Falls Church', 'Virginia', 'BWI', 'Maryland', 149, 0, 49.6, 'on', '2022-05-15 09:53:45'),
(9, 'DCA', 'Virginia', 'Loudoun', 'Virginia', 142, 0, 47.4, 'on', '2022-05-15 09:55:12'),
(10, 'Loudoun', 'Virginia', 'DCA', 'Virginia', 142, 0, 47.4, 'on', '2022-05-15 09:55:12'),
(11, 'BWI', 'Maryland', 'Fort Washington', 'Maryland', 139, 0, 46.2, 'on', '2022-05-15 09:55:40'),
(12, 'Fort Washington', 'Maryland', 'BWI', 'Maryland', 139, 0, 46.2, 'on', '2022-05-15 09:55:40'),
(13, 'BWI', 'Maryland', 'Alexandria', 'Virginia', 134, 0, 44.8, 'on', '2022-05-15 09:56:29'),
(14, 'Alexandria', 'Virginia', 'BWI', 'Maryland', 134, 0, 44.8, 'on', '2022-05-15 09:56:29'),
(15, 'BWI', 'Maryland', 'McLean', 'Virginia', 134, 0, 44.7, 'on', '2022-05-15 09:56:45'),
(16, 'McLean', 'Virginia', 'BWI', 'Maryland', 134, 0, 44.7, 'on', '2022-05-15 09:56:45'),
(23, 'Alexandria', 'Virginia', 'Fort Washington', 'Maryland', 130, 0, 43.3, 'on', '2022-05-15 13:06:19'),
(24, 'Fort Washington', 'Maryland', 'Alexandria', 'Virginia', 130, 0, 43.3, 'on', '2022-05-15 13:06:19'),
(25, 'Bethesda', 'Maryland', 'Fort Washington', 'Maryland', 123, 0, 41, 'on', '2022-05-15 13:07:12'),
(26, 'Fort Washington', 'Maryland', 'Bethesda', 'Maryland', 123, 0, 41, 'on', '2022-05-15 13:07:12'),
(27, 'Bethesda', 'Maryland', 'Loudoun', 'Virginia', 123, 0, 41, 'on', '2022-05-15 13:07:40'),
(28, 'Loudoun', 'Virginia', 'Bethesda', 'Maryland', 123, 0, 41, 'on', '2022-05-15 13:07:40'),
(29, 'IAD', 'Virginia', 'Hyattsville', 'Maryland', 111, 0, 37.1, 'on', '2022-05-15 13:08:10'),
(30, 'Hyattsville', 'Maryland', 'IAD', 'Virginia', 111, 0, 37.1, 'on', '2022-05-15 13:08:10'),
(31, 'Falls Church', 'Virginia', 'Loudoun', 'Virginia', 111, 0, 37, 'on', '2022-05-15 13:08:39'),
(32, 'Loudoun', 'Virginia', 'Falls Church', 'Virginia', 111, 0, 37, 'on', '2022-05-15 13:08:39'),
(33, 'BWI', 'Maryland', 'DCA', 'Virginia', 110, 0, 36.8, 'on', '2022-05-15 13:08:54'),
(34, 'DCA', 'Virginia', 'BWI', 'Maryland', 110, 0, 36.8, 'on', '2022-05-15 13:08:54'),
(35, 'BWI', 'Maryland', 'Bethesda', 'Maryland', 106, 0, 35.3, 'on', '2022-05-15 13:09:54'),
(36, 'Bethesda', 'Maryland', 'BWI', 'Maryland', 106, 0, 35.3, 'on', '2022-05-15 13:09:54'),
(37, 'IAD', 'Virginia', 'Alexandria', 'Virginia', 102, 0, 34, 'on', '2022-05-15 13:10:33'),
(38, 'Alexandria', 'Virginia', 'IAD', 'Virginia', 102, 0, 34, 'on', '2022-05-15 13:10:33'),
(39, 'BWI', 'Maryland', 'Silver Spring', 'Maryland', 95, 0, 31.7, 'on', '2022-05-15 13:11:21'),
(40, 'Silver Spring', 'Maryland', 'BWI', 'Maryland', 95, 0, 31.7, 'on', '2022-05-15 13:11:21'),
(41, 'IAD', 'Virginia', 'Silver Spring', 'Maryland', 91, 0, 30.4, 'on', '2022-05-15 13:11:48'),
(42, 'Silver Spring', 'Maryland', 'IAD', 'Virginia', 91, 0, 30.4, 'on', '2022-05-15 13:11:48'),
(43, 'IAD', 'Virginia', 'DCA', 'Virginia', 87, 0, 29.1, 'on', '2022-05-15 13:12:05'),
(44, 'DCA', 'Virginia', 'IAD', 'Virginia', 87, 0, 29.1, 'on', '2022-05-15 13:12:05'),
(45, 'Falls Church', 'Virginia', 'Fort Washington', 'Maryland', 83, 0, 27.8, 'on', '2022-05-15 13:12:27'),
(46, 'Fort Washington', 'Maryland', 'Falls Church', 'Virginia', 83, 0, 27.8, 'on', '2022-05-15 13:12:28'),
(47, 'Falls Church', 'Virginia', 'Hyattsville', 'Maryland', 82, 0, 27.3, 'on', '2022-05-15 13:13:23'),
(48, 'Hyattsville', 'Maryland', 'Falls Church', 'Virginia', 82, 0, 27.3, 'on', '2022-05-15 13:13:23'),
(49, 'IAD', 'Virginia', 'Bethesda', 'Maryland', 81, 0, 27, 'on', '2022-05-15 13:13:44'),
(50, 'Bethesda', 'Maryland', 'IAD', 'Virginia', 81, 0, 27, 'on', '2022-05-15 13:13:44'),
(51, 'BWI', 'Maryland', 'Hyattsville', 'Maryland', 79, 0, 26.4, 'on', '2022-05-15 13:14:18'),
(52, 'Hyattsville', 'Maryland', 'BWI', 'Maryland', 79, 0, 26.4, 'on', '2022-05-15 13:14:18'),
(53, 'Alexandria', 'Virginia', 'Bethesda', 'Maryland', 75, 0, 24.9, 'on', '2022-05-15 13:14:49'),
(54, 'Bethesda', 'Maryland', 'Alexandria', 'Virginia', 75, 0, 24.9, 'on', '2022-05-15 13:14:49'),
(55, 'DCA', 'Virginia', 'Bethesda', 'Maryland', 66, 0, 22, 'on', '2022-05-15 13:15:24'),
(56, 'Bethesda', 'Maryland', 'DCA', 'Virginia', 66, 0, 22, 'on', '2022-05-15 13:15:24'),
(57, 'Richmond', 'Virginia', 'Crystal City', 'Virginia', 351, 0, 117, 'on', '2022-05-16 06:29:39'),
(58, 'Crystal City', 'Virginia', 'Richmond', 'Virginia', 351, 0, 117, 'on', '2022-05-16 06:29:39');

-- --------------------------------------------------------

--
-- Table structure for table `settings_ad_source_values`
--

CREATE TABLE `settings_ad_source_values` (
  `key_settings_ad_source_values` int(10) UNSIGNED NOT NULL,
  `ad_source` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_ad_source_values`
--

INSERT INTO `settings_ad_source_values` (`key_settings_ad_source_values`, `ad_source`, `entry_date_time`) VALUES
(1, 'Print media', '2022-06-01 18:18:38'),
(2, 'Radio', '2022-06-01 18:19:27'),
(3, 'Television', '2022-06-01 18:19:32'),
(4, 'Film', '2022-06-01 18:19:36'),
(5, 'Direct mail', '2022-06-01 18:19:47'),
(6, 'Email marketing', '2022-06-01 18:20:13'),
(7, 'Social media', '2022-06-01 18:20:26'),
(8, 'Referral', '2022-06-01 18:21:14'),
(9, 'Billboard', '2022-06-06 15:02:25');

-- --------------------------------------------------------

--
-- Table structure for table `settings_airline_values`
--

CREATE TABLE `settings_airline_values` (
  `key_settings_airline_values` int(10) UNSIGNED NOT NULL,
  `airline` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_company`
--

CREATE TABLE `settings_company` (
  `key_settings_company` int(10) UNSIGNED NOT NULL,
  `company_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `company_label` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slogan` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone1` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone2` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `website1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `website2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_media_url1` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_media_url2` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_media_url3` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_media_url4` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_media_url5` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_url1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_url2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_company`
--

INSERT INTO `settings_company` (`key_settings_company`, `company_name`, `company_label`, `slogan`, `address1`, `address2`, `city`, `state`, `zip_code`, `country`, `phone1`, `phone2`, `email1`, `email2`, `website1`, `website2`, `social_media_url1`, `social_media_url2`, `social_media_url3`, `social_media_url4`, `social_media_url5`, `notes`, `image_url1`, `image_url2`, `entry_date_time`) VALUES
(1, 'My Livery Dispatch Company', 'MLDC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2022-05-16 07:15:29');

-- --------------------------------------------------------

--
-- Table structure for table `settings_country_values`
--

CREATE TABLE `settings_country_values` (
  `key_settings_country_values` int(10) UNSIGNED NOT NULL,
  `country` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_country_values`
--

INSERT INTO `settings_country_values` (`key_settings_country_values`, `country`, `country_code`, `entry_date_time`) VALUES
(1, 'United States', 'USA', '2022-05-27 16:07:36');

-- --------------------------------------------------------

--
-- Table structure for table `settings_dispatch_area_values`
--

CREATE TABLE `settings_dispatch_area_values` (
  `key_settings_dispatch_area_values` int(10) UNSIGNED NOT NULL,
  `dispatch_area` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_email_configuration`
--

CREATE TABLE `settings_email_configuration` (
  `key_settings_email_configuration` int(10) UNSIGNED NOT NULL,
  `sender_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sender_password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `reply_to_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `copy_to_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `smtp_address` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_email_configuration`
--

INSERT INTO `settings_email_configuration` (`key_settings_email_configuration`, `sender_email`, `sender_password`, `reply_to_email`, `copy_to_email`, `smtp_address`, `entry_date_time`) VALUES
(1, 'sender@gmail.com', '', 'getter@gmail.com', '', '', '2022-05-16 07:14:41');

-- --------------------------------------------------------

--
-- Table structure for table `settings_extra_charges_values`
--

CREATE TABLE `settings_extra_charges_values` (
  `key_settings_extra_charges_values` int(10) UNSIGNED NOT NULL,
  `category` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_insurance_company_values`
--

CREATE TABLE `settings_insurance_company_values` (
  `key_settings_insurance_company_values` int(10) UNSIGNED NOT NULL,
  `insurance_company` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_landmark_values`
--

CREATE TABLE `settings_landmark_values` (
  `key_settings_landmark_values` int(10) UNSIGNED NOT NULL,
  `category` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_offtime_type_values`
--

CREATE TABLE `settings_offtime_type_values` (
  `key_settings_offtime_type_values` int(10) UNSIGNED NOT NULL,
  `offtime_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_payment_card_type_values`
--

CREATE TABLE `settings_payment_card_type_values` (
  `key_settings_payment_card_type_values` int(10) UNSIGNED NOT NULL,
  `payment_card_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_payment_card_type_values`
--

INSERT INTO `settings_payment_card_type_values` (`key_settings_payment_card_type_values`, `payment_card_type`, `entry_date_time`) VALUES
(1, 'Mastercard', '2022-06-01 16:18:41'),
(2, 'Visa', '2022-06-01 16:18:47'),
(3, 'Citibank', '2022-06-01 16:18:56'),
(4, 'Chase Bank', '2022-06-01 16:19:02'),
(5, 'Bank of America', '2022-06-01 16:19:07'),
(6, 'Discover', '2022-06-01 16:19:25');

-- --------------------------------------------------------

--
-- Table structure for table `settings_payment_method_values`
--

CREATE TABLE `settings_payment_method_values` (
  `key_settings_payment_method_values` int(10) UNSIGNED NOT NULL,
  `payment_method` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_payment_method_values`
--

INSERT INTO `settings_payment_method_values` (`key_settings_payment_method_values`, `payment_method`, `entry_date_time`) VALUES
(1, 'Cash', '2022-06-01 18:16:46'),
(2, 'Check', '2022-06-01 18:17:04'),
(3, 'Debit card', '2022-06-01 18:17:13'),
(4, 'Credit card', '2022-06-01 18:17:20'),
(5, 'Mobile payment', '2022-06-01 18:17:29'),
(6, 'Electronic bank transfer', '2022-06-01 18:17:45');

-- --------------------------------------------------------

--
-- Table structure for table `settings_staff_designation_values`
--

CREATE TABLE `settings_staff_designation_values` (
  `key_settings_staff_designation_values` int(10) UNSIGNED NOT NULL,
  `designation` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entry_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_staff_designation_values`
--

INSERT INTO `settings_staff_designation_values` (`key_settings_staff_designation_values`, `designation`, `entry_date_time`) VALUES
(1, 'Dispatcher', '2022-05-22 16:53:22'),
(2, 'Dispatch Manager', '2022-05-22 16:57:26');

-- --------------------------------------------------------

--
-- Table structure for table `settings_state_values`
--

CREATE TABLE `settings_state_values` (
  `key_settings_state_values` int(10) UNSIGNED NOT NULL,
  `state` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_state_values`
--

INSERT INTO `settings_state_values` (`key_settings_state_values`, `state`, `state_code`, `country`, `entry_date_time`) VALUES
(1, 'Virginia', 'VA', 'United States', '2022-05-15 09:35:35'),
(2, 'Maryland', 'MD', 'United States', '2022-05-15 09:35:42'),
(3, 'New York', 'NY', 'United States', '2022-05-15 09:35:50'),
(4, 'District of Columbia', 'DC', 'United States', '2022-05-21 15:28:50'),
(5, 'Florida', 'FL', 'United States', '2022-05-22 16:29:52'),
(6, 'New Jersey', 'NJ', 'United States', '2022-05-22 16:29:59'),
(7, 'Texas', 'TX', 'United States', '2022-05-22 16:30:14'),
(8, 'California', 'CA', 'United States', '2022-05-27 16:14:46'),
(9, 'Wyoming', 'WY', 'United States', '2022-05-27 16:15:10'),
(10, 'Pennsylvania', 'PA', 'United States', '2022-05-27 16:15:22'),
(11, 'Rhode Island', 'RI', 'United States', '2022-05-27 16:15:30'),
(12, 'Idaho', 'ID', 'United States', '2022-05-27 16:15:44'),
(13, 'Indiana', 'IN', 'United States', '2022-05-27 16:15:51'),
(14, 'Washington', 'WA', 'United States', '2022-05-27 16:15:58'),
(17, 'Ohio', 'OH', 'United States', '2022-05-28 15:18:08'),
(18, 'Illinois', 'IL', 'United States', '2022-05-28 17:37:21'),
(19, 'New Mexico', 'NM', 'United States', '2022-05-28 17:37:31'),
(20, 'Missouri', 'MO', 'United States', '2022-06-01 16:43:23'),
(21, 'Georgia', 'GA', 'United States', '2022-06-01 16:43:35'),
(22, 'Michigan', 'MI', 'United States', '2022-06-01 16:43:57'),
(23, 'Arizona', 'AZ', 'United States', '2022-06-01 16:44:11'),
(24, 'Maine', 'ME', 'United States', '2022-06-01 16:44:21'),
(25, 'Montana', 'MT', 'United States', '2022-06-01 16:44:39'),
(26, 'Tennessee', 'TN', 'United States', '2022-06-06 14:10:22'),
(27, 'South Carolina', 'SC', 'United States', '2022-06-06 14:10:35'),
(28, 'Colorado', 'CO', 'United States', '2022-06-06 14:11:02'),
(29, 'Wisconsin', 'WI', 'United States', '2022-06-06 14:11:17'),
(30, 'Alaska', 'AK', 'United States', '2022-06-06 14:11:27'),
(31, 'North Carolina', 'NC', 'United States', '2022-06-06 14:11:43');

-- --------------------------------------------------------

--
-- Table structure for table `settings_toll_type_values`
--

CREATE TABLE `settings_toll_type_values` (
  `key_settings_toll_type_values` int(10) UNSIGNED NOT NULL,
  `toll_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_trips`
--

CREATE TABLE `settings_trips` (
  `key_settings_trips` int(10) UNSIGNED NOT NULL,
  `gratuity_percent` float NOT NULL DEFAULT '0',
  `gas_surcharge_percent` float NOT NULL DEFAULT '0',
  `admin_fee_percent` float NOT NULL DEFAULT '0',
  `tax_percent` float NOT NULL DEFAULT '0',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_trips`
--

INSERT INTO `settings_trips` (`key_settings_trips`, `gratuity_percent`, `gas_surcharge_percent`, `admin_fee_percent`, `tax_percent`, `entry_date_time`) VALUES
(1, 20, 2, 0, 0, '2022-05-16 07:13:32');

-- --------------------------------------------------------

--
-- Table structure for table `settings_trip_status_values`
--

CREATE TABLE `settings_trip_status_values` (
  `key_settings_trip_status_values` int(10) UNSIGNED NOT NULL,
  `trip_status` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `text_color` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `back_color` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sort` tinyint(4) NOT NULL DEFAULT '0',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_trip_type_values`
--

CREATE TABLE `settings_trip_type_values` (
  `key_settings_trip_type_values` int(10) UNSIGNED NOT NULL,
  `trip_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_vehicle_make_values`
--

CREATE TABLE `settings_vehicle_make_values` (
  `key_settings_vehicle_make_values` int(10) UNSIGNED NOT NULL,
  `vehicle_make` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_vehicle_make_values`
--

INSERT INTO `settings_vehicle_make_values` (`key_settings_vehicle_make_values`, `vehicle_make`, `entry_date_time`) VALUES
(1, 'Mercedes-Benz', '2022-05-16 07:05:46'),
(2, 'BMW', '2022-05-16 07:05:58'),
(3, 'Cadillac', '2022-05-16 07:07:51'),
(4, 'Lexus', '2022-05-16 07:08:02'),
(5, 'Lincoln', '2022-05-16 07:08:16'),
(6, 'Land Rover', '2022-05-16 07:08:38'),
(7, 'Ford', '2022-05-16 12:50:32'),
(8, 'Motor Coach Industries', '2022-05-16 14:55:47');

-- --------------------------------------------------------

--
-- Table structure for table `settings_vehicle_model_values`
--

CREATE TABLE `settings_vehicle_model_values` (
  `key_settings_vehicle_model_values` int(10) UNSIGNED NOT NULL,
  `vehicle_model` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vehicle_make` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_vehicle_model_values`
--

INSERT INTO `settings_vehicle_model_values` (`key_settings_vehicle_model_values`, `vehicle_model`, `vehicle_make`, `entry_date_time`) VALUES
(1, 'X7', 'BMW', '2022-05-16 09:47:17'),
(2, '8-Series', 'BMW', '2022-05-16 09:47:35'),
(3, 'M3 E92', 'BMW', '2022-05-16 09:47:56'),
(4, '7-Series', 'BMW', '2022-05-16 09:48:17'),
(5, 'C 300', 'Mercedes-Benz', '2022-05-16 09:51:49'),
(6, 'E 350', 'Mercedes-Benz', '2022-05-16 09:52:03'),
(7, 'CLA 250', 'Mercedes-Benz', '2022-05-16 09:52:17'),
(8, 'MKZ', 'Lincoln', '2022-05-16 09:53:07'),
(9, 'Aviator', 'Lincoln', '2022-05-16 09:53:18'),
(11, 'MKC', 'Lincoln', '2022-05-16 09:53:43'),
(12, 'ATS-V', 'Cadillac', '2022-05-16 09:55:09'),
(13, 'CT5-V Blackwing', 'Cadillac', '2022-05-16 09:55:35'),
(14, 'Transit 150', 'Ford', '2022-05-16 12:51:29'),
(15, 'Transit 350', 'Ford', '2022-05-16 12:53:07'),
(16, 'Escalade', 'Cadillac', '2022-05-16 14:01:47'),
(17, 'E4500', 'Motor Coach Industries', '2022-05-16 14:56:09');

-- --------------------------------------------------------

--
-- Table structure for table `settings_vehicle_type_values`
--

CREATE TABLE `settings_vehicle_type_values` (
  `key_settings_vehicle_type_values` int(10) UNSIGNED NOT NULL,
  `vehicle_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_vehicle_type_values`
--

INSERT INTO `settings_vehicle_type_values` (`key_settings_vehicle_type_values`, `vehicle_type`, `entry_date_time`) VALUES
(1, 'Sedan', '2022-05-16 07:09:32'),
(2, 'SUV', '2022-05-16 07:09:42'),
(3, 'Van', '2022-05-16 07:10:05'),
(4, 'Coach', '2022-05-16 07:10:27');

-- --------------------------------------------------------

--
-- Table structure for table `settings_workshop_name_values`
--

CREATE TABLE `settings_workshop_name_values` (
  `key_settings_workshop_name_values` int(10) UNSIGNED NOT NULL,
  `workshop_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contact_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `key_staff` int(10) UNSIGNED NOT NULL,
  `image_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `designation` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_phone_extension` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mobile_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date_of_birth` date DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `social_security_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notes` varchar(3000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payroll_period` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `salary_amount` float NOT NULL DEFAULT '0',
  `annual_paid_days` smallint(6) NOT NULL DEFAULT '0',
  `house_rent_allowance` float NOT NULL DEFAULT '0',
  `conveyance_allowance` float NOT NULL DEFAULT '0',
  `hourly_regular_rate` float NOT NULL DEFAULT '0',
  `hourly_overtime_rate` float NOT NULL DEFAULT '0',
  `hours_per_week` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`key_staff`, `image_url`, `username`, `password`, `designation`, `first_name`, `last_name`, `address1`, `address2`, `city`, `state`, `zip_code`, `work_phone`, `work_phone_extension`, `mobile_phone`, `email`, `date_of_birth`, `hire_date`, `social_security_number`, `notes`, `payroll_period`, `salary_amount`, `annual_paid_days`, `house_rent_allowance`, `conveyance_allowance`, `hourly_regular_rate`, `hourly_overtime_rate`, `hours_per_week`, `active_status`, `entry_date_time`) VALUES
(1, '', 'roosevelt', '123456', 'Dispatcher', 'Roosevelt', 'Hoffis', '60 Old Dover Rd', '', 'Hialeah', 'Florida', '33014', '305-622-4739', '', '305-302-1135', 'roosevelt.hoffis@aol.com', '1994-07-24', '2020-04-15', '694-54-5491', '', 'Weekly', 0, 0, 0, 0, 15, 20, '40', 'on', '2022-05-22 16:39:56'),
(2, '', 'marina', '123456', 'Dispatch Manager', 'Marina', 'Halter', '8 Sheridan Rd', '', 'Jersey City', 'New Jersey', '07304', '201-832-4168', '', '201-412-3040', 'hhalter@yahoo.com', '1987-04-11', '2020-08-15', '974-45-9547', '', 'Weekly', 0, 0, 0, 0, 20, 25, '40', 'on', '2022-05-22 17:05:05'),
(3, '', 'lorean', '123456', 'Dispatcher', 'Lorean', 'Martabano', '85092 Southern Blvd', '', 'San Antonio', 'Texas', '78204', '210-856-4979', '', '210-634-2447', 'lorean.martabano@hotmail.com', '1999-09-19', '2019-07-24', '354-97-1294', '', 'Weekly', 0, 0, 0, 0, 15, 20, '40', 'on', '2022-05-22 17:07:05'),
(4, '', 'france', '123456', 'Dispatcher', 'France', 'Buzick', '64 Newman Springs Rd E', '', 'Brooklyn', 'New Jersey', '11219', '718-478-8504', '', '718-853-3740', 'france.buzick@yahoo.com', '2000-02-19', '2018-11-20', '657-48-1246', '', 'Weekly', 0, 0, 0, 0, 15, 20, '40', 'on', '2022-05-22 17:08:48'),
(5, '', 'jerry', '123456', 'Dispatcher', 'Jerry', 'Dallen', '393 Lafayette Ave', '', 'Richmond', 'Virginia', '23219', '804-762-9576', '', '804-808-9574', 'jerry.dallen@yahoo.com', '2001-08-17', '2020-12-20', '957-56-3491', '', 'Weekly', 0, 0, 0, 0, 15, 20, '40', 'on', '2022-05-22 17:10:13');

-- --------------------------------------------------------

--
-- Table structure for table `trips`
--

CREATE TABLE `trips` (
  `key_trips` int(10) UNSIGNED NOT NULL,
  `key_customer_invoices` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_driver_payroll` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_customer_passengers` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_customer_contacts` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_drivers` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_vehicles` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_settings_airline_values` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_rates_zones` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `reference_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `passenger_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `total_passengers` smallint(6) NOT NULL DEFAULT '0',
  `reserved_by` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pickup_datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dropoff_datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `trip_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `trip_status` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `driver_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vehicle` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `airline` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `flight_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zone_from` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zone_to` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `routing_from` varchar(3000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `routing_to` varchar(3000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `routing_notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dispatcher_notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `rate_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `hourly_regular_rate` float NOT NULL DEFAULT '0',
  `regular_hours` smallint(6) NOT NULL DEFAULT '0',
  `regular_minutes` tinyint(4) NOT NULL DEFAULT '0',
  `hourly_regular_amount` float NOT NULL DEFAULT '0',
  `hourly_wait_rate` float NOT NULL DEFAULT '0',
  `wait_hours` smallint(11) NOT NULL DEFAULT '0',
  `wait_minutes` tinyint(11) NOT NULL DEFAULT '0',
  `hourly_wait_amount` float NOT NULL DEFAULT '0',
  `hourly_overtime_rate` float NOT NULL DEFAULT '0',
  `overtime_hours` smallint(6) NOT NULL DEFAULT '0',
  `overtime_minutes` tinyint(4) NOT NULL DEFAULT '0',
  `hourly_overtime_amount` float NOT NULL DEFAULT '0',
  `zone_rate` float NOT NULL DEFAULT '0',
  `base_amount` float NOT NULL DEFAULT '0',
  `offtime_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `offtime_amount` float NOT NULL DEFAULT '0',
  `extra_stops` tinyint(4) NOT NULL DEFAULT '0',
  `extra_stops_amount` float NOT NULL DEFAULT '0',
  `toll_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tolls_amount` float NOT NULL DEFAULT '0',
  `parking_amount` float NOT NULL DEFAULT '0',
  `gratuity_percent` float NOT NULL DEFAULT '0',
  `gratuity_amount` float NOT NULL DEFAULT '0',
  `gas_surcharge_percent` float NOT NULL DEFAULT '0',
  `gas_surcharge_amount` float NOT NULL DEFAULT '0',
  `admin_fee_percent` float NOT NULL DEFAULT '0',
  `admin_fee_amount` float NOT NULL DEFAULT '0',
  `discount_percent` float NOT NULL DEFAULT '0',
  `discount_amount` float NOT NULL DEFAULT '0',
  `tax_percent` float NOT NULL DEFAULT '0',
  `tax_amount` float NOT NULL DEFAULT '0',
  `trip_extra_charges` float NOT NULL DEFAULT '0',
  `flat_amount` float NOT NULL DEFAULT '0',
  `total_trip_amount` float NOT NULL DEFAULT '0',
  `pay_base_amount_percent` float NOT NULL DEFAULT '0',
  `pay_driver_base_amount` float NOT NULL DEFAULT '0',
  `pay_offtime_percent` float NOT NULL DEFAULT '0',
  `pay_offtime_amount` float NOT NULL DEFAULT '0',
  `pay_extra_stops_percent` float DEFAULT '0',
  `pay_extra_stops_amount` float NOT NULL DEFAULT '0',
  `pay_tolls_percent` float NOT NULL DEFAULT '0',
  `pay_tolls_amount` float NOT NULL DEFAULT '0',
  `pay_parking_percent` float NOT NULL DEFAULT '0',
  `pay_parking_amount` float NOT NULL DEFAULT '0',
  `pay_gratuity_percent` float NOT NULL DEFAULT '0',
  `pay_gratuity_amount` float NOT NULL DEFAULT '0',
  `pay_gas_surcharge_percent` float NOT NULL DEFAULT '0',
  `pay_gas_surcharge_amount` float NOT NULL DEFAULT '0',
  `pay_commission_percent` float NOT NULL DEFAULT '0',
  `pay_commission_amount` float NOT NULL DEFAULT '0',
  `pay_flat_amount` float NOT NULL DEFAULT '0',
  `pay_total_driver_amount` float NOT NULL DEFAULT '0',
  `pay_notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `concluded_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `settled_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `invoiced_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `trips`
--

INSERT INTO `trips` (`key_trips`, `key_customer_invoices`, `key_driver_payroll`, `key_customer_passengers`, `key_customer_contacts`, `key_drivers`, `key_vehicles`, `key_settings_airline_values`, `key_rates_zones`, `reference_number`, `passenger_name`, `total_passengers`, `reserved_by`, `pickup_datetime`, `dropoff_datetime`, `trip_type`, `trip_status`, `driver_name`, `vehicle`, `airline`, `flight_number`, `zone_from`, `zone_to`, `routing_from`, `routing_to`, `routing_notes`, `dispatcher_notes`, `rate_type`, `hourly_regular_rate`, `regular_hours`, `regular_minutes`, `hourly_regular_amount`, `hourly_wait_rate`, `wait_hours`, `wait_minutes`, `hourly_wait_amount`, `hourly_overtime_rate`, `overtime_hours`, `overtime_minutes`, `hourly_overtime_amount`, `zone_rate`, `base_amount`, `offtime_type`, `offtime_amount`, `extra_stops`, `extra_stops_amount`, `toll_type`, `tolls_amount`, `parking_amount`, `gratuity_percent`, `gratuity_amount`, `gas_surcharge_percent`, `gas_surcharge_amount`, `admin_fee_percent`, `admin_fee_amount`, `discount_percent`, `discount_amount`, `tax_percent`, `tax_amount`, `trip_extra_charges`, `flat_amount`, `total_trip_amount`, `pay_base_amount_percent`, `pay_driver_base_amount`, `pay_offtime_percent`, `pay_offtime_amount`, `pay_extra_stops_percent`, `pay_extra_stops_amount`, `pay_tolls_percent`, `pay_tolls_amount`, `pay_parking_percent`, `pay_parking_amount`, `pay_gratuity_percent`, `pay_gratuity_amount`, `pay_gas_surcharge_percent`, `pay_gas_surcharge_amount`, `pay_commission_percent`, `pay_commission_amount`, `pay_flat_amount`, `pay_total_driver_amount`, `pay_notes`, `concluded_checkbox`, `settled_checkbox`, `invoiced_checkbox`, `entry_date_time`) VALUES
(1, 0, 0, 1, 2, 3001, 1002, 0, 4, '', 'Blair Malet', 1, 'Tamar Hoogland', '2022-06-07 11:40:00', '2022-06-04 01:00:00', '', '', 'Tyra Shields', 'Sedan (F1235)', '', '', 'BWI, Maryland', 'IAD, Virginia', '123', '123', '', '', 'Zone', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 175, 175, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 175, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', '2022-06-04 14:53:16');

-- --------------------------------------------------------

--
-- Table structure for table `trip_extra_charges`
--

CREATE TABLE `trip_extra_charges` (
  `key_trip_extra_charges` int(10) UNSIGNED NOT NULL,
  `key_trips` int(10) UNSIGNED NOT NULL,
  `category` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `amount` float DEFAULT '0',
  `notes` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `key_vehicles` int(10) UNSIGNED NOT NULL,
  `key_settings_insurance_company_values` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `fleet_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vehicle_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vin_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `year_made` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `make` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `model` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `max_seats` int(10) NOT NULL DEFAULT '0',
  `color` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `insurance_company` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `insurance_expiry_date` date DEFAULT NULL,
  `image_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zone_rate_percent` float NOT NULL DEFAULT '0',
  `hourly_regular_rate` float NOT NULL DEFAULT '0',
  `hourly_wait_rate` float NOT NULL DEFAULT '0',
  `hourly_overtime_rate` float NOT NULL DEFAULT '0',
  `notes` varchar(3000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`key_vehicles`, `key_settings_insurance_company_values`, `fleet_number`, `vehicle_type`, `tag`, `vin_number`, `year_made`, `make`, `model`, `max_seats`, `color`, `insurance_company`, `insurance_expiry_date`, `image_url`, `zone_rate_percent`, `hourly_regular_rate`, `hourly_wait_rate`, `hourly_overtime_rate`, `notes`, `active_status`, `entry_date_time`) VALUES
(1001, 0, 'F1234', 'SUV', 'LDS-1234', '12345678910', '2022', 'BMW', 'X7', 7, 'White', '', '1970-01-01', 'https://i.ibb.co/BZbnmRr/bmwx7.jpg', 130, 120, 140, 140, '', 'on', '2022-05-16 12:00:10'),
(1002, 0, 'F1235', 'Sedan', 'LDS-1235', '12345678911', '2020', 'BMW', '7-Series', 3, 'Black', '', '1970-01-01', 'https://i.ibb.co/PQVqj1W/bmw7series.jpg', 100, 105, 115, 115, '', 'on', '2022-05-16 12:05:12'),
(1003, 0, 'F1236', 'Sedan', 'LDS-1236', '12345678912', '2017', 'Cadillac', 'ATS-V', 3, 'Black', '', '1970-01-01', 'https://i.ibb.co/0Ggbgj2/cadillacatsv.jpg', 100, 105, 115, 115, '', 'on', '2022-05-16 12:09:00'),
(1004, 0, 'F1237', 'Sedan', 'LDS-1237', '12345678913', '2022', 'Cadillac', 'CT5-V Blackwing', 3, 'White', '', '1970-01-01', 'https://i.ibb.co/vPxcyVz/cadillacct5v.jpg', 100, 110, 120, 120, '', 'on', '2022-05-16 12:11:08'),
(1005, 0, 'F1238', 'Van', 'LDS-1238', '12345678914', '2021', 'Ford', 'Transit 350', 15, 'Black', '', '1970-01-01', 'https://i.ibb.co/YjY6z4Q/fordtransit350.jpg', 200, 150, 170, 170, '', 'on', '2022-05-16 12:57:08'),
(1006, 0, 'F1239', 'Van', 'LDS-1239', '12345678915', '2020', 'Ford', 'Transit 150', 11, 'White', '', '1970-01-01', 'https://i.ibb.co/7Yf2k41/fordtransit150.jpg', 175, 150, 170, 170, '', 'on', '2022-05-16 13:57:34'),
(1007, 0, 'F1240', 'SUV', 'LDS-1240', '12345678916', '2019', 'Cadillac', 'Escalade', 7, 'Black', '', '1970-01-01', 'https://i.ibb.co/X4P4QvZ/cadillacescalade.jpg', 140, 140, 150, 150, '', 'on', '2022-05-16 14:01:02'),
(1008, 0, 'F1241', 'Coach', 'LDS-1241', '12345678917', '2020', 'Motor Coach Industries', 'E4500', 55, 'Black', '', '1970-01-01', 'https://i.ibb.co/ZMHMBVn/mcie4500.jpg', 350, 250, 300, 300, '', 'on', '2022-05-16 14:58:16');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles_maintenance`
--

CREATE TABLE `vehicles_maintenance` (
  `key_vehicles_maintenance` int(10) UNSIGNED NOT NULL,
  `key_vehicles` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `repair_date` date DEFAULT NULL,
  `repair_description` varchar(3000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `workshop_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `labor_cost` float NOT NULL DEFAULT '0',
  `parts_cost` float NOT NULL DEFAULT '0',
  `warranty_description` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `warranty_expiration` date DEFAULT NULL,
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer_address_book`
--
ALTER TABLE `customer_address_book`
  ADD PRIMARY KEY (`key_customer_address_book`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `key_customer_passengers` (`key_customer_passengers`);
ALTER TABLE `customer_address_book` ADD FULLTEXT KEY `phpblink_fulltext` (`title`,`category`,`city`,`zip_code`);

--
-- Indexes for table `customer_billing_contacts`
--
ALTER TABLE `customer_billing_contacts`
  ADD PRIMARY KEY (`key_customer_billing_contacts`),
  ADD UNIQUE KEY `card_number` (`card_number`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `customer_billing_contacts` ADD FULLTEXT KEY `customer_billing_contacts_fulltext` (`contact_name`,`card_type`,`name_on_card`);

--
-- Indexes for table `customer_companies`
--
ALTER TABLE `customer_companies`
  ADD PRIMARY KEY (`key_customer_companies`),
  ADD UNIQUE KEY `company_name` (`company_name`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `customer_companies` ADD FULLTEXT KEY `customer_companies_fulltext` (`company_name`,`address1`,`state`,`zip_code`,`country`);

--
-- Indexes for table `customer_contacts`
--
ALTER TABLE `customer_contacts`
  ADD PRIMARY KEY (`key_customer_contacts`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `key_customer_companies` (`key_customer_companies`);
ALTER TABLE `customer_contacts` ADD FULLTEXT KEY `customer_contacts_fulltext` (`company_name`,`first_name`,`last_name`,`address1`,`address2`,`city`,`state`,`zip_code`,`country`,`email`);

--
-- Indexes for table `customer_invoices`
--
ALTER TABLE `customer_invoices`
  ADD PRIMARY KEY (`key_customer_invoices`),
  ADD KEY `key_customer_passengers` (`key_customer_passengers`),
  ADD KEY `end_date` (`end_date`),
  ADD KEY `due_date` (`due_date`),
  ADD KEY `payment_method` (`payment_method`);

--
-- Indexes for table `customer_passengers`
--
ALTER TABLE `customer_passengers`
  ADD PRIMARY KEY (`key_customer_passengers`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `key_customer_companies` (`key_customer_companies`),
  ADD KEY `key_customer_rate_packages` (`key_customer_rate_packages`),
  ADD KEY `key_customer_billing_contacts` (`key_customer_billing_contacts`);
ALTER TABLE `customer_passengers` ADD FULLTEXT KEY `customer_passengers_fulltext` (`first_name`,`last_name`,`address1`,`city`,`state`,`country`,`zip_code`,`email`,`ad_source`);

--
-- Indexes for table `customer_rate_packages`
--
ALTER TABLE `customer_rate_packages`
  ADD PRIMARY KEY (`key_customer_rate_packages`),
  ADD UNIQUE KEY `package_name` (`package_name`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `customer_rate_packages` ADD FULLTEXT KEY `customer_rate_packages_fulltext` (`package_name`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`key_drivers`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `key_vehicles` (`key_vehicles`);
ALTER TABLE `drivers` ADD FULLTEXT KEY `drivers_fulltext` (`first_name`,`last_name`,`contract_type`,`city`,`state`,`zip_code`,`fleet_number`);

--
-- Indexes for table `driver_payroll`
--
ALTER TABLE `driver_payroll`
  ADD PRIMARY KEY (`key_driver_payroll`),
  ADD KEY `end_date` (`end_date`),
  ADD KEY `due_date` (`due_date`),
  ADD KEY `payment_method` (`payment_method`),
  ADD KEY `key_drivers` (`key_drivers`);
ALTER TABLE `driver_payroll` ADD FULLTEXT KEY `driver_payroll_fulltext` (`payment_method`);

--
-- Indexes for table `landmarks`
--
ALTER TABLE `landmarks`
  ADD PRIMARY KEY (`key_landmarks`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `landmarks` ADD FULLTEXT KEY `landmarks_fulltext` (`title`,`category`,`city`,`zip_code`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`key_logs`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `log_datetime` (`log_datetime`);
ALTER TABLE `logs` ADD FULLTEXT KEY `logs_fulltext` (`log_type`,`action_performed`);

--
-- Indexes for table `rates_zones`
--
ALTER TABLE `rates_zones`
  ADD PRIMARY KEY (`key_rates_zones`),
  ADD KEY `from_city` (`from_city`),
  ADD KEY `from_state` (`from_state`),
  ADD KEY `to_city` (`to_city`),
  ADD KEY `to_state` (`to_state`);

--
-- Indexes for table `settings_ad_source_values`
--
ALTER TABLE `settings_ad_source_values`
  ADD PRIMARY KEY (`key_settings_ad_source_values`),
  ADD UNIQUE KEY `ad_source` (`ad_source`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_ad_source_values` ADD FULLTEXT KEY `settings_ad_source_values_fulltext` (`ad_source`);

--
-- Indexes for table `settings_airline_values`
--
ALTER TABLE `settings_airline_values`
  ADD PRIMARY KEY (`key_settings_airline_values`),
  ADD UNIQUE KEY `airline` (`airline`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_airline_values` ADD FULLTEXT KEY `settings_airline_values_fulltext` (`airline`);

--
-- Indexes for table `settings_company`
--
ALTER TABLE `settings_company`
  ADD PRIMARY KEY (`key_settings_company`),
  ADD KEY `entry_date_time` (`entry_date_time`);

--
-- Indexes for table `settings_country_values`
--
ALTER TABLE `settings_country_values`
  ADD PRIMARY KEY (`key_settings_country_values`),
  ADD UNIQUE KEY `country` (`country`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_country_values` ADD FULLTEXT KEY `settings_country_values_fulltext` (`country`,`country_code`);

--
-- Indexes for table `settings_dispatch_area_values`
--
ALTER TABLE `settings_dispatch_area_values`
  ADD PRIMARY KEY (`key_settings_dispatch_area_values`),
  ADD UNIQUE KEY `dispatch_area` (`dispatch_area`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_dispatch_area_values` ADD FULLTEXT KEY `settings_dispatch_area_values_fulltext` (`dispatch_area`);

--
-- Indexes for table `settings_email_configuration`
--
ALTER TABLE `settings_email_configuration`
  ADD PRIMARY KEY (`key_settings_email_configuration`),
  ADD KEY `entry_date_time` (`entry_date_time`);

--
-- Indexes for table `settings_extra_charges_values`
--
ALTER TABLE `settings_extra_charges_values`
  ADD PRIMARY KEY (`key_settings_extra_charges_values`),
  ADD UNIQUE KEY `category` (`category`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_extra_charges_values` ADD FULLTEXT KEY `settings_extra_charges_values_fulltext` (`category`);

--
-- Indexes for table `settings_insurance_company_values`
--
ALTER TABLE `settings_insurance_company_values`
  ADD PRIMARY KEY (`key_settings_insurance_company_values`),
  ADD UNIQUE KEY `insurance_company` (`insurance_company`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_insurance_company_values` ADD FULLTEXT KEY `settings_insurance_company_values_fulltext` (`insurance_company`);

--
-- Indexes for table `settings_landmark_values`
--
ALTER TABLE `settings_landmark_values`
  ADD PRIMARY KEY (`key_settings_landmark_values`),
  ADD UNIQUE KEY `category` (`category`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_landmark_values` ADD FULLTEXT KEY `settings_landmark_values_fulltext` (`category`);

--
-- Indexes for table `settings_offtime_type_values`
--
ALTER TABLE `settings_offtime_type_values`
  ADD PRIMARY KEY (`key_settings_offtime_type_values`),
  ADD UNIQUE KEY `offtime_type` (`offtime_type`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_offtime_type_values` ADD FULLTEXT KEY `settings_offtime_type_values_fulltext` (`offtime_type`);

--
-- Indexes for table `settings_payment_card_type_values`
--
ALTER TABLE `settings_payment_card_type_values`
  ADD PRIMARY KEY (`key_settings_payment_card_type_values`),
  ADD UNIQUE KEY `payment_card_type` (`payment_card_type`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_payment_card_type_values` ADD FULLTEXT KEY `settings_payment_card_type_values_fulltext` (`payment_card_type`);

--
-- Indexes for table `settings_payment_method_values`
--
ALTER TABLE `settings_payment_method_values`
  ADD PRIMARY KEY (`key_settings_payment_method_values`),
  ADD UNIQUE KEY `payment_method` (`payment_method`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_payment_method_values` ADD FULLTEXT KEY `settings_payment_method_values_fulltext` (`payment_method`);

--
-- Indexes for table `settings_staff_designation_values`
--
ALTER TABLE `settings_staff_designation_values`
  ADD PRIMARY KEY (`key_settings_staff_designation_values`),
  ADD UNIQUE KEY `designation` (`designation`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_staff_designation_values` ADD FULLTEXT KEY `settings_staff_designation_values_fulltext` (`designation`);

--
-- Indexes for table `settings_state_values`
--
ALTER TABLE `settings_state_values`
  ADD PRIMARY KEY (`key_settings_state_values`),
  ADD UNIQUE KEY `state` (`state`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_state_values` ADD FULLTEXT KEY `settings_state_values_fulltext` (`state`,`state_code`,`country`);

--
-- Indexes for table `settings_toll_type_values`
--
ALTER TABLE `settings_toll_type_values`
  ADD PRIMARY KEY (`key_settings_toll_type_values`),
  ADD UNIQUE KEY `toll_type` (`toll_type`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_toll_type_values` ADD FULLTEXT KEY `settings_toll_type_values_fulltext` (`toll_type`);

--
-- Indexes for table `settings_trips`
--
ALTER TABLE `settings_trips`
  ADD PRIMARY KEY (`key_settings_trips`),
  ADD KEY `entry_date_time` (`entry_date_time`);

--
-- Indexes for table `settings_trip_status_values`
--
ALTER TABLE `settings_trip_status_values`
  ADD PRIMARY KEY (`key_settings_trip_status_values`),
  ADD UNIQUE KEY `trip_status` (`trip_status`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_trip_status_values` ADD FULLTEXT KEY `settings_trip_status_values_fulltext` (`trip_status`);

--
-- Indexes for table `settings_trip_type_values`
--
ALTER TABLE `settings_trip_type_values`
  ADD PRIMARY KEY (`key_settings_trip_type_values`),
  ADD UNIQUE KEY `trip_type` (`trip_type`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_trip_type_values` ADD FULLTEXT KEY `settings_trip_type_values_fulltext` (`trip_type`);

--
-- Indexes for table `settings_vehicle_make_values`
--
ALTER TABLE `settings_vehicle_make_values`
  ADD PRIMARY KEY (`key_settings_vehicle_make_values`),
  ADD UNIQUE KEY `vehicle_model` (`vehicle_make`),
  ADD KEY `entry_date_time` (`entry_date_time`);

--
-- Indexes for table `settings_vehicle_model_values`
--
ALTER TABLE `settings_vehicle_model_values`
  ADD PRIMARY KEY (`key_settings_vehicle_model_values`),
  ADD UNIQUE KEY `vehicle_model` (`vehicle_model`),
  ADD KEY `entry_date_time` (`entry_date_time`);

--
-- Indexes for table `settings_vehicle_type_values`
--
ALTER TABLE `settings_vehicle_type_values`
  ADD PRIMARY KEY (`key_settings_vehicle_type_values`),
  ADD UNIQUE KEY `vehicle_type` (`vehicle_type`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_vehicle_type_values` ADD FULLTEXT KEY `settings_vehicle_type_values_fulltext` (`vehicle_type`);

--
-- Indexes for table `settings_workshop_name_values`
--
ALTER TABLE `settings_workshop_name_values`
  ADD PRIMARY KEY (`key_settings_workshop_name_values`),
  ADD UNIQUE KEY `workshop_name` (`workshop_name`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_workshop_name_values` ADD FULLTEXT KEY `settings_workshop_name_values_fulltext` (`workshop_name`,`city`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`key_staff`);
ALTER TABLE `staff` ADD FULLTEXT KEY `staff_fulltext` (`designation`,`first_name`,`last_name`);

--
-- Indexes for table `trips`
--
ALTER TABLE `trips`
  ADD PRIMARY KEY (`key_trips`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `key_customer_invoices` (`key_customer_invoices`),
  ADD KEY `key_driver_payroll` (`key_driver_payroll`),
  ADD KEY `key_customer_passengers` (`key_customer_passengers`),
  ADD KEY `key_customer_contacts` (`key_customer_contacts`),
  ADD KEY `key_drivers` (`key_drivers`),
  ADD KEY `key_vehicles` (`key_vehicles`),
  ADD KEY `key_rates_zones` (`key_rates_zones`),
  ADD KEY `pickup_datetime` (`pickup_datetime`),
  ADD KEY `key_settings_airline_values` (`key_settings_airline_values`);
ALTER TABLE `trips` ADD FULLTEXT KEY `trips_fulltext` (`passenger_name`,`reference_number`,`reserved_by`,`trip_type`,`driver_name`,`vehicle`,`airline`,`flight_number`,`zone_from`,`zone_to`);

--
-- Indexes for table `trip_extra_charges`
--
ALTER TABLE `trip_extra_charges`
  ADD PRIMARY KEY (`key_trip_extra_charges`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `key_trips` (`key_trips`);
ALTER TABLE `trip_extra_charges` ADD FULLTEXT KEY `phpblink_fulltext` (`category`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`key_vehicles`),
  ADD UNIQUE KEY `fleet_number` (`fleet_number`),
  ADD UNIQUE KEY `vin_number` (`vin_number`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `key_insurance_company_values` (`key_settings_insurance_company_values`);
ALTER TABLE `vehicles` ADD FULLTEXT KEY `vehicles_fulltext` (`fleet_number`,`vehicle_type`,`tag`,`vin_number`,`year_made`,`model`,`color`,`notes`,`make`);

--
-- Indexes for table `vehicles_maintenance`
--
ALTER TABLE `vehicles_maintenance`
  ADD PRIMARY KEY (`key_vehicles_maintenance`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `key_vehicles` (`key_vehicles`),
  ADD KEY `repair_date` (`repair_date`);
ALTER TABLE `vehicles_maintenance` ADD FULLTEXT KEY `vehicles_maintenance_fulltext` (`repair_description`,`workshop_name`,`warranty_description`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer_address_book`
--
ALTER TABLE `customer_address_book`
  MODIFY `key_customer_address_book` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customer_billing_contacts`
--
ALTER TABLE `customer_billing_contacts`
  MODIFY `key_customer_billing_contacts` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `customer_companies`
--
ALTER TABLE `customer_companies`
  MODIFY `key_customer_companies` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `customer_contacts`
--
ALTER TABLE `customer_contacts`
  MODIFY `key_customer_contacts` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `customer_invoices`
--
ALTER TABLE `customer_invoices`
  MODIFY `key_customer_invoices` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customer_passengers`
--
ALTER TABLE `customer_passengers`
  MODIFY `key_customer_passengers` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `customer_rate_packages`
--
ALTER TABLE `customer_rate_packages`
  MODIFY `key_customer_rate_packages` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `key_drivers` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3008;
--
-- AUTO_INCREMENT for table `driver_payroll`
--
ALTER TABLE `driver_payroll`
  MODIFY `key_driver_payroll` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `landmarks`
--
ALTER TABLE `landmarks`
  MODIFY `key_landmarks` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `key_logs` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rates_zones`
--
ALTER TABLE `rates_zones`
  MODIFY `key_rates_zones` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `settings_ad_source_values`
--
ALTER TABLE `settings_ad_source_values`
  MODIFY `key_settings_ad_source_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `settings_airline_values`
--
ALTER TABLE `settings_airline_values`
  MODIFY `key_settings_airline_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings_company`
--
ALTER TABLE `settings_company`
  MODIFY `key_settings_company` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `settings_country_values`
--
ALTER TABLE `settings_country_values`
  MODIFY `key_settings_country_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `settings_dispatch_area_values`
--
ALTER TABLE `settings_dispatch_area_values`
  MODIFY `key_settings_dispatch_area_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings_email_configuration`
--
ALTER TABLE `settings_email_configuration`
  MODIFY `key_settings_email_configuration` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `settings_extra_charges_values`
--
ALTER TABLE `settings_extra_charges_values`
  MODIFY `key_settings_extra_charges_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings_insurance_company_values`
--
ALTER TABLE `settings_insurance_company_values`
  MODIFY `key_settings_insurance_company_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings_landmark_values`
--
ALTER TABLE `settings_landmark_values`
  MODIFY `key_settings_landmark_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings_offtime_type_values`
--
ALTER TABLE `settings_offtime_type_values`
  MODIFY `key_settings_offtime_type_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings_payment_card_type_values`
--
ALTER TABLE `settings_payment_card_type_values`
  MODIFY `key_settings_payment_card_type_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `settings_payment_method_values`
--
ALTER TABLE `settings_payment_method_values`
  MODIFY `key_settings_payment_method_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `settings_staff_designation_values`
--
ALTER TABLE `settings_staff_designation_values`
  MODIFY `key_settings_staff_designation_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `settings_state_values`
--
ALTER TABLE `settings_state_values`
  MODIFY `key_settings_state_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `settings_toll_type_values`
--
ALTER TABLE `settings_toll_type_values`
  MODIFY `key_settings_toll_type_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings_trips`
--
ALTER TABLE `settings_trips`
  MODIFY `key_settings_trips` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `settings_trip_status_values`
--
ALTER TABLE `settings_trip_status_values`
  MODIFY `key_settings_trip_status_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings_trip_type_values`
--
ALTER TABLE `settings_trip_type_values`
  MODIFY `key_settings_trip_type_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings_vehicle_make_values`
--
ALTER TABLE `settings_vehicle_make_values`
  MODIFY `key_settings_vehicle_make_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `settings_vehicle_model_values`
--
ALTER TABLE `settings_vehicle_model_values`
  MODIFY `key_settings_vehicle_model_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `settings_vehicle_type_values`
--
ALTER TABLE `settings_vehicle_type_values`
  MODIFY `key_settings_vehicle_type_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `settings_workshop_name_values`
--
ALTER TABLE `settings_workshop_name_values`
  MODIFY `key_settings_workshop_name_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `key_staff` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `trips`
--
ALTER TABLE `trips`
  MODIFY `key_trips` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `trip_extra_charges`
--
ALTER TABLE `trip_extra_charges`
  MODIFY `key_trip_extra_charges` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `key_vehicles` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1009;
--
-- AUTO_INCREMENT for table `vehicles_maintenance`
--
ALTER TABLE `vehicles_maintenance`
  MODIFY `key_vehicles_maintenance` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer_address_book`
--
ALTER TABLE `customer_address_book`
  ADD CONSTRAINT `customer_address_book_ibfk_1` FOREIGN KEY (`key_customer_passengers`) REFERENCES `customer_passengers` (`key_customer_passengers`) ON DELETE CASCADE;

--
-- Constraints for table `trip_extra_charges`
--
ALTER TABLE `trip_extra_charges`
  ADD CONSTRAINT `trip_extra_charges_ibfk_1` FOREIGN KEY (`key_trips`) REFERENCES `trips` (`key_trips`) ON DELETE CASCADE;

--
-- Constraints for table `vehicles_maintenance`
--
ALTER TABLE `vehicles_maintenance`
  ADD CONSTRAINT `vehicles_maintenance_ibfk_1` FOREIGN KEY (`key_vehicles`) REFERENCES `vehicles` (`key_vehicles`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
