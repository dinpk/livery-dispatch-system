-- phpMyAdmin SQL Dump
-- version 4.6.6deb5ubuntu0.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 07, 2022 at 02:40 AM
-- Server version: 5.7.37-0ubuntu0.18.04.1
-- PHP Version: 7.2.24-0ubuntu0.18.04.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `limopath`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer_address_book`
--

CREATE TABLE `customer_address_book` (
  `key_customer_address_book` int(10) UNSIGNED NOT NULL,
  `key_customer_passengers` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `category` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_address_book`
--

INSERT INTO `customer_address_book` (`key_customer_address_book`, `key_customer_passengers`, `title`, `category`, `address1`, `address2`, `city`, `state`, `zip_code`, `image_url`, `notes`, `entry_date_time`) VALUES
(1, 1, 'John Doe Office', '', '123 Almond Street', '', 'Fairfax', 'VA', '221445', '', 'some notes', '2021-09-28 01:51:06'),
(2, 2, 'Home', '', '1234 David Street', '', 'Dale City', 'Virginia', '22192', '', 'd', '2021-10-04 19:11:33');

-- --------------------------------------------------------

--
-- Table structure for table `customer_billing_contacts`
--

CREATE TABLE `customer_billing_contacts` (
  `key_customer_billing_contacts` int(10) UNSIGNED NOT NULL,
  `contact_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `card_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `card_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `card_expiration` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `card_security_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name_on_card` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `confirmation_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_billing_contacts`
--

INSERT INTO `customer_billing_contacts` (`key_customer_billing_contacts`, `contact_name`, `card_type`, `card_number`, `card_expiration`, `card_security_code`, `name_on_card`, `address1`, `address2`, `city`, `state`, `zip_code`, `confirmation_email`, `phone`, `notes`, `active_status`, `entry_date_time`) VALUES
(1, 'Sophia Taylor', 'American Express', '2158-5488-8548-5487', '', '', 'Sophia Taylor', '', '', '', 'Maryland', '', '', '', '', 'on', '2021-10-10 01:52:45'),
(2, 'David Taylor', 'American Express', '1548-554-78548-54', '', '', 'David Taylor', '', '', '', '', '', '', '', '', 'on', '2021-10-10 02:27:45'),
(3, 'Allen Donald Amex', 'American Express', '44587865488648654', '2023/04', '123', 'Allen Donald', '3387 Millon Way Rd.', '', 'Fairfax', 'Virginia', '21457', 'allendonald@gmail.com', '571-547-4785', 'Some notes Some notes Some notes Some notes Some notes Some notes Some notes Some notes Some notes Some notes Some notes Some notes Some notes.', 'on', '2021-10-18 02:17:34'),
(4, 'Julia Roberts Amex', 'American Express', '85486545158545', '', '', 'Julia Roberts', '', '', '', '', '', '', '', '', 'on', '2021-10-18 02:34:59');

-- --------------------------------------------------------

--
-- Table structure for table `customer_companies`
--

CREATE TABLE `customer_companies` (
  `key_customer_companies` int(10) UNSIGNED NOT NULL,
  `company_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_companies`
--

INSERT INTO `customer_companies` (`key_customer_companies`, `company_name`, `image_url`, `address1`, `address2`, `city`, `state`, `zip_code`, `country`, `active_status`, `entry_date_time`) VALUES
(1, 'Lucky Company', '', '', '', '', '', '', '', 'on', '2021-09-28 11:12:10'),
(2, 'Northern Cricket Club', '', '', '', '', 'Virginia', '', 'United States of America', 'on', '2021-10-18 02:16:31');

-- --------------------------------------------------------

--
-- Table structure for table `customer_contacts`
--

CREATE TABLE `customer_contacts` (
  `key_customer_contacts` int(10) UNSIGNED NOT NULL,
  `company_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `key_customer_companies` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `image_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_phone_extension` int(10) NOT NULL DEFAULT '0',
  `mobile_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_contacts`
--

INSERT INTO `customer_contacts` (`key_customer_contacts`, `company_name`, `key_customer_companies`, `image_url`, `first_name`, `last_name`, `address1`, `address2`, `city`, `state`, `zip_code`, `country`, `work_phone`, `work_phone_extension`, `mobile_phone`, `email`, `active_status`, `entry_date_time`) VALUES
(1, 'Northern Cricket Club', 2, '', 'Janet', 'Doe', '', '', '', '', '', 'United States of America', '', 0, '', '', 'on', '2021-09-28 11:17:00'),
(3, 'Lucky Company', 1, '', 'Julia', 'Doe', '', '', '', '', '', 'United States of America', '', 0, '', '', 'on', '2021-10-10 01:38:48'),
(4, 'Lucky Company', 1, '', 'Tiffany', 'Joseph', '1234 General Washington Dr.', 'Building # 4', 'Alexandria', 'Virginia', '21578', 'United States of America', '703-154-7848', 7, '703-123-4589', 'tiffanyjoseph@outlook.com', 'on', '2021-10-16 12:28:22');

-- --------------------------------------------------------

--
-- Table structure for table `customer_invoices`
--

CREATE TABLE `customer_invoices` (
  `key_customer_invoices` int(10) UNSIGNED NOT NULL,
  `key_customer_passengers` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `amount` float NOT NULL DEFAULT '0',
  `amount_paid` float NOT NULL DEFAULT '0',
  `payment_method` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `due_date` date DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_invoices`
--

INSERT INTO `customer_invoices` (`key_customer_invoices`, `key_customer_passengers`, `start_date`, `end_date`, `amount`, `amount_paid`, `payment_method`, `due_date`, `issue_date`, `notes`) VALUES
(1, 5, '2021-10-27', '2021-10-27', 115.32, 0, '', '2021-10-25', '2021-10-22', ''),
(1001, 3, '2021-10-27', '2021-10-27', 120.97, 121, '', '2021-10-28', '2021-10-22', ''),
(1002, 3, '2021-10-14', '2021-10-14', 476.04, 0, '', '2021-10-30', '2021-10-22', ''),
(1003, 5, '2021-10-18', '2021-10-18', 120.32, 0, '', '2021-10-30', '2021-10-27', ''),
(1004, 1, '2021-10-02', '2021-10-02', 315, 315, '', '2021-11-25', '2021-11-11', '');

-- --------------------------------------------------------

--
-- Table structure for table `customer_passengers`
--

CREATE TABLE `customer_passengers` (
  `key_customer_passengers` int(10) UNSIGNED NOT NULL,
  `key_customer_companies` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_customer_rate_packages` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_customer_billing_contacts` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `first_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_phone_extension` int(10) NOT NULL DEFAULT '0',
  `mobile_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `website` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `company_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `package_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `billing_contact_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payment_method` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `confirm_to_passenger` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `confirm_to_contact` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `confirm_to_billing_contact` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `trip_ticket_notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ad_source` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_passengers`
--

INSERT INTO `customer_passengers` (`key_customer_passengers`, `key_customer_companies`, `key_customer_rate_packages`, `key_customer_billing_contacts`, `first_name`, `last_name`, `address1`, `address2`, `city`, `state`, `country`, `zip_code`, `work_phone`, `work_phone_extension`, `mobile_phone`, `email`, `website`, `image_url`, `company_name`, `package_name`, `billing_contact_name`, `payment_method`, `confirm_to_passenger`, `confirm_to_contact`, `confirm_to_billing_contact`, `notes`, `trip_ticket_notes`, `ad_source`, `active_status`, `entry_date_time`) VALUES
(1, 1, 1, 0, 'John', 'Doe', '', '', '', '', 'United States of America', '', '', 0, '', 'johndoe@yahoo.com', '', '', 'Lucky Company', 'Regular', '', '', 'on', 'on', 'on', '', '', '', 'on', '2021-10-03 11:56:40'),
(2, 1, 1, 3, 'David', 'Joseph', '', '', '', '', 'United States of America', '', '', 0, '', 'davidjospeh@live.com', '', '', 'Lucky Company', 'Regular', 'Allen Donald Amex', '', 'on', 'on', 'on', 'general notes', 'trip notes', '', 'on', '2021-10-04 19:10:37'),
(3, 1, 2, 1, 'Mark', 'Taylor', 'a', '', '', '', 'United States of America', '', '', 0, '703-456-1597', 'marktaylor@outlook.com', '', '', 'Lucky Company', 'Value Ride', 'Sophia Taylor', 'Cash', 'on', 'on', 'on', '', '', '', 'on', '2021-10-10 01:52:57'),
(4, 2, 1, 3, 'Allen', 'Donald', '8345 Lake River Dr.', '', 'Arlington', 'Virginia', 'United States of America', '224788', '703-487-4515', 0, '701-457-4154', 'allendonald@gmail.com', 'https://allendonaldonline.info', '', 'Northern Cricket Club', 'Regular', 'Allen Donald Amex', 'Cash', 'on', 'on', 'on', 'Some profile notes Some profile notes Some profile notes Some profile notes Some profile notes Some profile notes Some profile notes Some profile notes', 'Trip ticket notes Trip ticket notes Trip ticket notes Trip ticket notes Trip ticket notes Trip ticket notes Trip ticket notes Trip ticket notes', '', 'on', '2021-10-18 02:17:55'),
(5, 2, 1, 4, 'Julia', 'Roberts', '', '', '', '', 'United States of America', '', '', 0, '571-123-4785', 'juliaroberts@msn.com', '', '', 'Northern Cricket Club', 'Regular', 'Julia Roberts Amex', '', 'on', 'on', 'on', 'a', '', '', 'on', '2021-10-18 02:35:10');

-- --------------------------------------------------------

--
-- Table structure for table `customer_rate_packages`
--

CREATE TABLE `customer_rate_packages` (
  `key_customer_rate_packages` int(10) UNSIGNED NOT NULL,
  `package_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `gratuity_percent` float NOT NULL DEFAULT '0',
  `gas_surcharge_percent` float NOT NULL DEFAULT '0',
  `admin_fee_percent` float NOT NULL DEFAULT '0',
  `discount_percent` float NOT NULL DEFAULT '0',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_rate_packages`
--

INSERT INTO `customer_rate_packages` (`key_customer_rate_packages`, `package_name`, `gratuity_percent`, `gas_surcharge_percent`, `admin_fee_percent`, `discount_percent`, `entry_date_time`) VALUES
(1, 'Regular', 20, 1.2, 1.1, 0.1, '2021-10-06 14:41:44'),
(2, 'Value Ride', 0, 0, 0, 4.9, '2021-10-10 12:19:13');

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `key_drivers` int(10) UNSIGNED NOT NULL,
  `key_vehicles` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `image_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contract_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_phone_extension` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mobile_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date_of_birth` date DEFAULT NULL,
  `license_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `license_expiry_date` date DEFAULT NULL,
  `social_security_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `hire_date` date DEFAULT NULL,
  `fleet_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payment_method` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `base_amount_percent` float NOT NULL DEFAULT '0',
  `pay_gratuity_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `gratuity_percent` float NOT NULL DEFAULT '0',
  `pay_commission_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `commission_percent` float NOT NULL DEFAULT '0',
  `pay_extra_stops_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extra_stops_percent` float NOT NULL DEFAULT '0',
  `pay_offtime_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `offtime_percent` float NOT NULL DEFAULT '0',
  `pay_tolls_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tolls_percent` float NOT NULL DEFAULT '0',
  `pay_parking_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `parking_percent` float NOT NULL DEFAULT '0',
  `pay_gas_surcharge_checkbox` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `gas_surcharge_percent` float NOT NULL DEFAULT '0',
  `pay_extra_charges_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extra_charges_percent` float NOT NULL DEFAULT '0',
  `notes` varchar(3000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `drivers`
--

INSERT INTO `drivers` (`key_drivers`, `key_vehicles`, `image_url`, `username`, `password`, `first_name`, `last_name`, `contract_type`, `address1`, `address2`, `city`, `state`, `zip_code`, `work_phone`, `work_phone_extension`, `mobile_phone`, `email`, `date_of_birth`, `license_number`, `license_expiry_date`, `social_security_number`, `hire_date`, `fleet_number`, `payment_method`, `base_amount_percent`, `pay_gratuity_checkbox`, `gratuity_percent`, `pay_commission_checkbox`, `commission_percent`, `pay_extra_stops_checkbox`, `extra_stops_percent`, `pay_offtime_checkbox`, `offtime_percent`, `pay_tolls_checkbox`, `tolls_percent`, `pay_parking_checkbox`, `parking_percent`, `pay_gas_surcharge_checkbox`, `gas_surcharge_percent`, `pay_extra_charges_checkbox`, `extra_charges_percent`, `notes`, `active_status`, `entry_date_time`) VALUES
(1, 1, '', 'saadiqbal', '1234567kdie', 'Saad', 'Iqbaal', '', '', '', '', 'Maryland', '', '', '', '', 'saadiqbal3457@outlook.com', '1977-06-28', '', '2023-03-16', '', '2008-06-25', 'Sedan (B145)', '', 40, 'on', 100, 'on', 4, 'on', 100, 'on', 50, 'on', 100, 'on', 100, 'on', 100, 'on', 100, '', 'on', '2021-09-28 02:31:24'),
(2, 1, '', 'falaksher', '12345567', 'Falak', 'Sher', '', '1234 Oakwood Dr.', '', 'Annandale', 'Virginia', '22003', '703-544-5488', '25', '703-124-1548', 'falaksher123@gmail.com', '1980-09-07', 'sd98039sd983', '2023-05-08', '118-34-8275', '2010-09-10', 'Sedan (B145)', 'Cash', 50, 'on', 100, 'on', 1.5, 'on', 95, 'on', 95, 'on', 95, 'on', 95, 'on', 95, 'on', 95, 'Some notes about the driver', 'on', '2021-10-06 16:05:01');

-- --------------------------------------------------------

--
-- Table structure for table `driver_payroll`
--

CREATE TABLE `driver_payroll` (
  `key_driver_payroll` int(10) UNSIGNED NOT NULL,
  `key_drivers` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `amount` float NOT NULL DEFAULT '0',
  `amount_paid` float NOT NULL DEFAULT '0',
  `payment_method` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `due_date` date DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `driver_payroll`
--

INSERT INTO `driver_payroll` (`key_driver_payroll`, `key_drivers`, `start_date`, `end_date`, `amount`, `amount_paid`, `payment_method`, `due_date`, `issue_date`, `notes`) VALUES
(1, 1, '2021-10-01', '2021-10-31', 179, 179, 'Cash', '2021-12-10', '2021-10-14', ''),
(2, 2, '2021-10-01', '2021-10-31', 351.97, 300, '', '2021-12-10', '2021-10-14', ''),
(3, 1, '2021-10-27', '2021-10-27', 54, 54, '', '2021-11-06', '2021-10-14', '');

-- --------------------------------------------------------

--
-- Table structure for table `landmarks`
--

CREATE TABLE `landmarks` (
  `key_landmarks` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `category` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notes` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `landmarks`
--

INSERT INTO `landmarks` (`key_landmarks`, `title`, `category`, `image_url`, `address1`, `address2`, `city`, `state`, `country`, `zip_code`, `notes`, `active_status`, `entry_date_time`) VALUES
(1, 'Shenandoah National Park - Virginia', '', '', '3655 US Highway 211', '', 'East Luray', 'Virginia', 'United States of America', '22835', '', 'on', '2021-10-04 13:09:39'),
(2, 'Colonial Williamsburg', '', '', '101 Visitor Center Dr', '', 'Williamsburg', 'Virginia', 'United States of America', '23185', '', 'on', '2021-10-04 13:57:48'),
(3, 'Virginia Beach', '', '', '', '', 'Virginia Beach', 'Virginia', 'United States of America', '23450', '', 'on', '2021-10-04 14:00:15'),
(4, 'Arlington National Cemetery', '', '', '1 Memorial Ave.', '', 'Arlington', 'Virginia', 'United States of America', '22211', '', 'on', '2021-10-04 14:00:30'),
(5, 'Mount Vernon', '', '', '3200 Mount Vernon Memorial Hwy', '', 'Mount Vernon', 'Virginia', 'United States of America', '22121', '', 'on', '2021-10-04 14:00:46'),
(6, 'Monticello and Charlottesville', '', '', ' 931 Thomas Jefferson Pkwy', '', 'Charlottesville', 'Virginia', 'United States of America', '22902', '', 'on', '2021-10-04 14:01:04'),
(7, 'Luray Caverns', '', '', '101 Cave Hill Rd', '', 'Luray', 'Virginia', 'United States of America', '22835', '', 'on', '2021-10-04 14:01:25'),
(8, 'Virginia Museum of Fine Arts', '', '', '200 N Arthur Ashe Blvd', '', 'Richmond', 'Virginia', 'United States of America', '23220', '', 'on', '2021-10-04 14:01:42'),
(9, 'Busch Gardens', '', '', '1 Busch Gardens Blvd', '', 'Williamsburg', 'Virginia', 'United States of America', '23185', '', 'on', '2021-10-04 14:01:59'),
(10, 'Jamestown and Yorktown', '', '', '2110 Jamestown Rd', '', 'Williamsburg', 'Virginia', 'United States of America', '23185', '', 'on', '2021-10-04 14:02:17'),
(11, 'Steven F. Udvar-Hazy Center', '', '', '14390 Air and Space Museum Pkwy', '', 'Chantilly', 'Virginia', 'United States of America', '20151', '', 'on', '2021-10-04 14:02:36'),
(12, 'Virginia State Capitol', '', '', '1000 Bank St', '', 'Richmond', 'Virginia', 'United States of America', '23218', '', 'on', '2021-10-04 14:02:55'),
(13, 'Natural Bridge', '', '', '15 Appledore Lane', '', 'Natural Bridge', 'Virginia', 'United States of America', '24578', '', 'on', '2021-10-04 14:03:11'),
(14, 'Chincoteague Islands', '', '', '5048 Main St', '', 'Chincoteague', 'Virginia', 'United States of America', '23336', '', 'on', '2021-10-04 14:03:27'),
(15, 'Virginia Aquarium & Marine Science Center', '', '', '717 General Booth Blvd', '', 'Virginia Beach', 'Virginia', 'United States of America', '23451', 'a', 'on', '2021-10-04 14:03:45'),
(16, 'Manassas National Battlefield', '', '', '6511 Sudley Rd', '', 'Manassas', 'Virginia', 'United States of America', '20109', '', 'on', '2021-10-04 14:03:59');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `key_logs` int(10) UNSIGNED NOT NULL,
  `log_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `log_datetime` datetime DEFAULT CURRENT_TIMESTAMP,
  `action_performed` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rates_zones`
--

CREATE TABLE `rates_zones` (
  `key_rates_zones` int(10) UNSIGNED NOT NULL,
  `from_city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `from_state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `from_zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `rate` float NOT NULL DEFAULT '0',
  `tolls` float NOT NULL DEFAULT '0',
  `miles` float NOT NULL DEFAULT '0',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `rates_zones`
--

INSERT INTO `rates_zones` (`key_rates_zones`, `from_city`, `from_state`, `from_zip_code`, `to_city`, `to_state`, `to_zip_code`, `rate`, `tolls`, `miles`, `active_status`, `entry_date_time`) VALUES
(1, 'Arlington', 'Virginia', '21458', 'Baltimore', 'Maryland', '20458', 90, 3, 0, 'on', '2021-09-28 10:41:20');

-- --------------------------------------------------------

--
-- Table structure for table `settings_ad_source_values`
--

CREATE TABLE `settings_ad_source_values` (
  `key_settings_ad_source_values` int(10) UNSIGNED NOT NULL,
  `ad_source` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_airline_values`
--

CREATE TABLE `settings_airline_values` (
  `key_settings_airline_values` int(10) UNSIGNED NOT NULL,
  `airline` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_airline_values`
--

INSERT INTO `settings_airline_values` (`key_settings_airline_values`, `airline`, `entry_date_time`) VALUES
(1, 'United Airlines', '2021-10-23 13:44:49'),
(3, 'Delta Airlines', '2021-10-23 13:45:16');

-- --------------------------------------------------------

--
-- Table structure for table `settings_company`
--

CREATE TABLE `settings_company` (
  `key_settings_company` int(10) UNSIGNED NOT NULL,
  `company_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `company_label` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slogan` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone1` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone2` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `website1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `website2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_media_url1` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_media_url2` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_media_url3` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_media_url4` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_media_url5` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_url1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_url2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_company`
--

INSERT INTO `settings_company` (`key_settings_company`, `company_name`, `company_label`, `slogan`, `address1`, `address2`, `city`, `state`, `zip_code`, `country`, `phone1`, `phone2`, `email1`, `email2`, `website1`, `website2`, `social_media_url1`, `social_media_url2`, `social_media_url3`, `social_media_url4`, `social_media_url5`, `notes`, `image_url1`, `image_url2`, `entry_date_time`) VALUES
(1, 'Business Company', 'BUSICOMP', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2021-10-01 16:19:05');

-- --------------------------------------------------------

--
-- Table structure for table `settings_country_values`
--

CREATE TABLE `settings_country_values` (
  `key_settings_country_values` int(10) UNSIGNED NOT NULL,
  `country` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_country_values`
--

INSERT INTO `settings_country_values` (`key_settings_country_values`, `country`, `country_code`, `entry_date_time`) VALUES
(1, 'United States of America', 'USA', '2021-10-04 13:52:08');

-- --------------------------------------------------------

--
-- Table structure for table `settings_dispatch_area_values`
--

CREATE TABLE `settings_dispatch_area_values` (
  `key_settings_dispatch_area_values` int(10) UNSIGNED NOT NULL,
  `dispatch_area` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_email_configuration`
--

CREATE TABLE `settings_email_configuration` (
  `key_settings_email_configuration` int(10) UNSIGNED NOT NULL,
  `sender_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sender_password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `reply_to_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `copy_to_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `smtp_address` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_email_configuration`
--

INSERT INTO `settings_email_configuration` (`key_settings_email_configuration`, `sender_email`, `sender_password`, `reply_to_email`, `copy_to_email`, `smtp_address`, `entry_date_time`) VALUES
(1, 'sender@busicomp.com', '123456567', 'replyto@busicomp.com', 'copyto@busicomp.com', 'smtp.busicomp.com', '2021-10-01 16:20:40');

-- --------------------------------------------------------

--
-- Table structure for table `settings_extra_charges_values`
--

CREATE TABLE `settings_extra_charges_values` (
  `key_settings_extra_charges_values` int(10) UNSIGNED NOT NULL,
  `category` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_extra_charges_values`
--

INSERT INTO `settings_extra_charges_values` (`key_settings_extra_charges_values`, `category`, `entry_date_time`) VALUES
(1, 'Coffee', '2021-10-10 17:00:31'),
(2, 'Baby seat', '2021-10-10 17:00:44'),
(3, 'Bottled water', '2021-10-10 17:00:54');

-- --------------------------------------------------------

--
-- Table structure for table `settings_insurance_company_values`
--

CREATE TABLE `settings_insurance_company_values` (
  `key_settings_insurance_company_values` int(10) UNSIGNED NOT NULL,
  `insurance_company` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_insurance_company_values`
--

INSERT INTO `settings_insurance_company_values` (`key_settings_insurance_company_values`, `insurance_company`, `entry_date_time`) VALUES
(1, 'Nationwide Insurance Company', '2021-10-18 13:12:05');

-- --------------------------------------------------------

--
-- Table structure for table `settings_landmark_values`
--

CREATE TABLE `settings_landmark_values` (
  `key_settings_landmark_values` int(10) UNSIGNED NOT NULL,
  `category` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_offtime_type_values`
--

CREATE TABLE `settings_offtime_type_values` (
  `key_settings_offtime_type_values` int(10) UNSIGNED NOT NULL,
  `offtime_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_offtime_type_values`
--

INSERT INTO `settings_offtime_type_values` (`key_settings_offtime_type_values`, `offtime_type`, `entry_date_time`) VALUES
(1, 'Early', '2021-10-24 09:44:43'),
(2, 'Late', '2021-10-24 09:44:50');

-- --------------------------------------------------------

--
-- Table structure for table `settings_payment_card_type_values`
--

CREATE TABLE `settings_payment_card_type_values` (
  `key_settings_payment_card_type_values` int(10) UNSIGNED NOT NULL,
  `payment_card_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_payment_card_type_values`
--

INSERT INTO `settings_payment_card_type_values` (`key_settings_payment_card_type_values`, `payment_card_type`, `entry_date_time`) VALUES
(1, 'American Express', '2021-10-10 01:50:59'),
(2, 'Visa', '2021-10-24 09:47:22');

-- --------------------------------------------------------

--
-- Table structure for table `settings_payment_method_values`
--

CREATE TABLE `settings_payment_method_values` (
  `key_settings_payment_method_values` int(10) UNSIGNED NOT NULL,
  `payment_method` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_payment_method_values`
--

INSERT INTO `settings_payment_method_values` (`key_settings_payment_method_values`, `payment_method`, `entry_date_time`) VALUES
(1, 'Cash', '2021-10-24 09:49:03'),
(2, 'Credit Card', '2021-10-24 09:49:11');

-- --------------------------------------------------------

--
-- Table structure for table `settings_state_values`
--

CREATE TABLE `settings_state_values` (
  `key_settings_state_values` int(10) UNSIGNED NOT NULL,
  `state` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_state_values`
--

INSERT INTO `settings_state_values` (`key_settings_state_values`, `state`, `state_code`, `entry_date_time`) VALUES
(1, 'Virginia', 'VA', '2021-10-01 17:34:57'),
(2, 'Maryland', 'MD', '2021-10-01 17:35:08');

-- --------------------------------------------------------

--
-- Table structure for table `settings_toll_type_values`
--

CREATE TABLE `settings_toll_type_values` (
  `key_settings_toll_type_values` int(10) UNSIGNED NOT NULL,
  `toll_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_toll_type_values`
--

INSERT INTO `settings_toll_type_values` (`key_settings_toll_type_values`, `toll_type`, `entry_date_time`) VALUES
(1, 'Cash', '2021-10-24 10:21:40');

-- --------------------------------------------------------

--
-- Table structure for table `settings_trips`
--

CREATE TABLE `settings_trips` (
  `key_settings_trips` int(10) UNSIGNED NOT NULL,
  `gratuity_percent` float NOT NULL DEFAULT '0',
  `gas_surcharge_percent` float NOT NULL DEFAULT '0',
  `admin_fee_percent` float NOT NULL DEFAULT '0',
  `tax_percent` float NOT NULL DEFAULT '0',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_trips`
--

INSERT INTO `settings_trips` (`key_settings_trips`, `gratuity_percent`, `gas_surcharge_percent`, `admin_fee_percent`, `tax_percent`, `entry_date_time`) VALUES
(1, 20, 0.5, 0.3, 2.5, '2021-10-08 04:18:28');

-- --------------------------------------------------------

--
-- Table structure for table `settings_trip_status_values`
--

CREATE TABLE `settings_trip_status_values` (
  `key_settings_trip_status_values` int(10) UNSIGNED NOT NULL,
  `trip_status` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `text_color` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `back_color` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sort` tinyint(4) NOT NULL DEFAULT '0',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_trip_status_values`
--

INSERT INTO `settings_trip_status_values` (`key_settings_trip_status_values`, `trip_status`, `text_color`, `back_color`, `sort`, `active_status`, `entry_date_time`) VALUES
(1, 'Confirmed', '#ffffff', '#388c21', 0, 'on', '2021-10-01 16:26:13'),
(2, 'Dispatched', '#ffffff', '#093d53', 0, 'on', '2021-10-01 16:26:25'),
(3, 'Quoted', '#ffffff', '#9e8400', 0, 'on', '2021-10-24 10:24:10');

-- --------------------------------------------------------

--
-- Table structure for table `settings_trip_type_values`
--

CREATE TABLE `settings_trip_type_values` (
  `key_settings_trip_type_values` int(10) UNSIGNED NOT NULL,
  `trip_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_trip_type_values`
--

INSERT INTO `settings_trip_type_values` (`key_settings_trip_type_values`, `trip_type`, `entry_date_time`) VALUES
(1, 'Wedding', '2021-10-24 10:26:45'),
(2, 'Tour', '2021-10-24 10:27:38');

-- --------------------------------------------------------

--
-- Table structure for table `settings_vehicle_model_values`
--

CREATE TABLE `settings_vehicle_model_values` (
  `key_settings_vehicle_model_values` int(10) UNSIGNED NOT NULL,
  `vehicle_model` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings_vehicle_type_values`
--

CREATE TABLE `settings_vehicle_type_values` (
  `key_settings_vehicle_type_values` int(10) UNSIGNED NOT NULL,
  `vehicle_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_vehicle_type_values`
--

INSERT INTO `settings_vehicle_type_values` (`key_settings_vehicle_type_values`, `vehicle_type`, `entry_date_time`) VALUES
(1, 'Sedan', '2021-10-07 09:50:29'),
(2, 'SUV', '2021-10-18 18:36:04');

-- --------------------------------------------------------

--
-- Table structure for table `settings_workshop_name_values`
--

CREATE TABLE `settings_workshop_name_values` (
  `key_settings_workshop_name_values` int(10) UNSIGNED NOT NULL,
  `workshop_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contact_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings_workshop_name_values`
--

INSERT INTO `settings_workshop_name_values` (`key_settings_workshop_name_values`, `workshop_name`, `contact_name`, `address1`, `address2`, `phone`, `email`, `city`, `state`, `zip_code`, `entry_date_time`) VALUES
(1, 'Vine Street Workshop', '', '', '', '', '', 'Alexandria', '', '', '2021-10-24 10:33:22');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `key_staff` int(10) UNSIGNED NOT NULL,
  `image_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `designation` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip_code` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_phone_extension` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mobile_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date_of_birth` date DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `social_security_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notes` varchar(3000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payroll_period` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `salary_amount` float NOT NULL DEFAULT '0',
  `annual_paid_days` smallint(6) NOT NULL DEFAULT '0',
  `house_rent_allowance` float NOT NULL DEFAULT '0',
  `conveyance_allowance` float NOT NULL DEFAULT '0',
  `hourly_regular_rate` float NOT NULL DEFAULT '0',
  `hourly_overtime_rate` float NOT NULL DEFAULT '0',
  `hours_per_week` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`key_staff`, `image_url`, `username`, `password`, `designation`, `first_name`, `last_name`, `address1`, `address2`, `city`, `state`, `zip_code`, `work_phone`, `work_phone_extension`, `mobile_phone`, `email`, `date_of_birth`, `hire_date`, `social_security_number`, `notes`, `payroll_period`, `salary_amount`, `annual_paid_days`, `house_rent_allowance`, `conveyance_allowance`, `hourly_regular_rate`, `hourly_overtime_rate`, `hours_per_week`, `active_status`, `entry_date_time`) VALUES
(1, '', 'mauricio', 'asdfg', '', 'Mauricio', 'Trigo', '1232 Albany St.', 'Bulding 2-A', 'Fairfax', 'Virginia', '22145', '703-123-4587', '25', '571-123-4578', 'mauriciotrigo@outlook.com', '1980-05-12', '2001-05-04', '234-45-5578', 'Some notes', 'Semi-monthly', 2500, 15, 10, 5, 25, 40, '40', 'on', '2021-11-04 15:05:51');

-- --------------------------------------------------------

--
-- Table structure for table `trips`
--

CREATE TABLE `trips` (
  `key_trips` int(10) UNSIGNED NOT NULL,
  `key_customer_invoices` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_driver_payroll` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_customer_passengers` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_customer_contacts` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_drivers` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_vehicles` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_settings_airline_values` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key_rates_zones` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `reference_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `passenger_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `total_passengers` smallint(6) NOT NULL DEFAULT '0',
  `reserved_by` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pickup_datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dropoff_datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `trip_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `trip_status` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `driver_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vehicle` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `airline` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `flight_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zone_from` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zone_to` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `routing_from` varchar(3000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `routing_to` varchar(3000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `routing_notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dispatcher_notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `rate_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `hourly_regular_rate` float NOT NULL DEFAULT '0',
  `regular_hours` smallint(6) NOT NULL DEFAULT '0',
  `regular_minutes` tinyint(4) NOT NULL DEFAULT '0',
  `hourly_regular_amount` float NOT NULL DEFAULT '0',
  `hourly_wait_rate` float NOT NULL DEFAULT '0',
  `wait_hours` smallint(11) NOT NULL DEFAULT '0',
  `wait_minutes` tinyint(11) NOT NULL DEFAULT '0',
  `hourly_wait_amount` float NOT NULL DEFAULT '0',
  `hourly_overtime_rate` float NOT NULL DEFAULT '0',
  `overtime_hours` smallint(6) NOT NULL DEFAULT '0',
  `overtime_minutes` tinyint(4) NOT NULL DEFAULT '0',
  `hourly_overtime_amount` float NOT NULL DEFAULT '0',
  `zone_rate` float NOT NULL DEFAULT '0',
  `base_amount` float NOT NULL DEFAULT '0',
  `offtime_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `offtime_amount` float NOT NULL DEFAULT '0',
  `extra_stops` tinyint(4) NOT NULL DEFAULT '0',
  `extra_stops_amount` float NOT NULL DEFAULT '0',
  `toll_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tolls_amount` float NOT NULL DEFAULT '0',
  `parking_amount` float NOT NULL DEFAULT '0',
  `gratuity_percent` float NOT NULL DEFAULT '0',
  `gratuity_amount` float NOT NULL DEFAULT '0',
  `gas_surcharge_percent` float NOT NULL DEFAULT '0',
  `gas_surcharge_amount` float NOT NULL DEFAULT '0',
  `admin_fee_percent` float NOT NULL DEFAULT '0',
  `admin_fee_amount` float NOT NULL DEFAULT '0',
  `discount_percent` float NOT NULL DEFAULT '0',
  `discount_amount` float NOT NULL DEFAULT '0',
  `tax_percent` float NOT NULL DEFAULT '0',
  `tax_amount` float NOT NULL DEFAULT '0',
  `trip_extra_charges` float NOT NULL DEFAULT '0',
  `flat_amount` float NOT NULL DEFAULT '0',
  `total_trip_amount` float NOT NULL DEFAULT '0',
  `pay_base_amount_percent` float NOT NULL DEFAULT '0',
  `pay_driver_base_amount` float NOT NULL DEFAULT '0',
  `pay_offtime_percent` float NOT NULL DEFAULT '0',
  `pay_offtime_amount` float NOT NULL DEFAULT '0',
  `pay_extra_stops_percent` float DEFAULT '0',
  `pay_extra_stops_amount` float NOT NULL DEFAULT '0',
  `pay_tolls_percent` float NOT NULL DEFAULT '0',
  `pay_tolls_amount` float NOT NULL DEFAULT '0',
  `pay_parking_percent` float NOT NULL DEFAULT '0',
  `pay_parking_amount` float NOT NULL DEFAULT '0',
  `pay_gratuity_percent` float NOT NULL DEFAULT '0',
  `pay_gratuity_amount` float NOT NULL DEFAULT '0',
  `pay_gas_surcharge_percent` float NOT NULL DEFAULT '0',
  `pay_gas_surcharge_amount` float NOT NULL DEFAULT '0',
  `pay_commission_percent` float NOT NULL DEFAULT '0',
  `pay_commission_amount` float NOT NULL DEFAULT '0',
  `pay_flat_amount` float NOT NULL DEFAULT '0',
  `pay_total_driver_amount` float NOT NULL DEFAULT '0',
  `pay_notes` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `concluded_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `settled_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `invoiced_checkbox` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `trips`
--

INSERT INTO `trips` (`key_trips`, `key_customer_invoices`, `key_driver_payroll`, `key_customer_passengers`, `key_customer_contacts`, `key_drivers`, `key_vehicles`, `key_settings_airline_values`, `key_rates_zones`, `reference_number`, `passenger_name`, `total_passengers`, `reserved_by`, `pickup_datetime`, `dropoff_datetime`, `trip_type`, `trip_status`, `driver_name`, `vehicle`, `airline`, `flight_number`, `zone_from`, `zone_to`, `routing_from`, `routing_to`, `routing_notes`, `dispatcher_notes`, `rate_type`, `hourly_regular_rate`, `regular_hours`, `regular_minutes`, `hourly_regular_amount`, `hourly_wait_rate`, `wait_hours`, `wait_minutes`, `hourly_wait_amount`, `hourly_overtime_rate`, `overtime_hours`, `overtime_minutes`, `hourly_overtime_amount`, `zone_rate`, `base_amount`, `offtime_type`, `offtime_amount`, `extra_stops`, `extra_stops_amount`, `toll_type`, `tolls_amount`, `parking_amount`, `gratuity_percent`, `gratuity_amount`, `gas_surcharge_percent`, `gas_surcharge_amount`, `admin_fee_percent`, `admin_fee_amount`, `discount_percent`, `discount_amount`, `tax_percent`, `tax_amount`, `trip_extra_charges`, `flat_amount`, `total_trip_amount`, `pay_base_amount_percent`, `pay_driver_base_amount`, `pay_offtime_percent`, `pay_offtime_amount`, `pay_extra_stops_percent`, `pay_extra_stops_amount`, `pay_tolls_percent`, `pay_tolls_amount`, `pay_parking_percent`, `pay_parking_amount`, `pay_gratuity_percent`, `pay_gratuity_amount`, `pay_gas_surcharge_percent`, `pay_gas_surcharge_amount`, `pay_commission_percent`, `pay_commission_amount`, `pay_flat_amount`, `pay_total_driver_amount`, `pay_notes`, `concluded_checkbox`, `settled_checkbox`, `invoiced_checkbox`, `entry_date_time`) VALUES
(1, 0, 2, 1, 0, 2, 2, 0, 0, '', 'John Doe', 0, '', '2021-10-02 07:55:00', '1970-01-01 00:00:00', '', 'Dispatched', 'Falak Sher', 'SUV (A1234)', '', '', '', '', 'sdfasdfa\r\nNatural Bridge (15 Appledore Lane, , Natural Bridge, Virginia 24578', 'sdfasdfa\r\nVirginia State Capitol (1000 Bank St, , Richmond, Virginia 23218', '', '', 'Hourly', 70, 2, 35, 165, 40, 1, 0, 30, 90, 0, 0, 0, 0, 195, '', 0, 0, 0, '', 0, 0, 0, 0, 5, 9.75, 0, 0, 0, 0, 0, 0, 5, 0, 209.75, 50, 97.5, 15, 0, 14, 0, 13, 0, 12, 0, 100, 0, 10, 0.97, 9, 17.55, 0, 116.02, '', 'on', '', '', '2021-10-03 15:40:47'),
(2, 1004, 1, 1, 1, 2, 1, 0, 1, '', 'John Doe', 3, 'Janet Doe', '2021-10-02 16:05:00', '2021-10-02 16:57:00', 'Tour', 'Dispatched', 'Falak Sher', 'Sedan (B145)', '', '', 'Arlington, Virginia', 'Baltimore, Maryland', 'dsf2342af', 'fasd234', '', 'Flek Sher driver', 'Hourly', 55, 4, 0, 220, 30, 0, 30, 30, 60, 1, 0, 60, 0, 310, 'Early', 0, 0, 0, 'Cash', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 315, 40, 124, 50, 0, 100, 0, 100, 0, 100, 0, 100, 0, 100, 0, 4, 12.4, 0, 136.4, '', 'on', 'on', '', '2021-10-03 15:41:54'),
(3, 0, 0, 1, 0, 2, 1, 0, 1, '', 'John Doe', 2, '', '2021-08-15 00:00:00', '1970-01-01 00:00:00', '', 'Confirmed', 'Falak Sher', 'Sedan (B145)', '', '', 'Arlington, Virginia', 'Baltimore, Maryland', 'John Doe Office (123 Almond Street, , Fairfax, VA 221445', 'IAD', '', 'Saad Iqbaal driver', 'Hourly', 55, 3, 3, 220, 30, 2, 2, 90, 60, 4, 5, 300, 90.2, 610, '', 0, 0, 0, '', 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5.4, 0, 620.4, 50, 305, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 305, '', 'on', 'on', '', '2021-10-06 16:12:15'),
(4, 1002, 2, 3, 0, 2, 1, 0, 1, 'E039458', 'Mark Taylor', 0, '', '2021-10-14 10:08:00', '1970-01-01 00:00:00', '', 'Confirmed', 'Falak Sher', 'Sedan (B145)', '', '', 'Arlington, Virginia', 'Baltimore, Maryland', 'Virginia Beach (, , Virginia Beach, Virginia 23450', 'Virginia State Capitol (1000 Bank St, , Richmond, Virginia 23218', '', '', 'Hourly', 56, 4, 0, 224, 31, 0, 23, 31, 60, 0, 54, 60, 90, 315, '', 10, 0, 20, '', 3, 0, 31, 97.65, 0.5, 1.57, 0.3, 0.94, 0, 0, 2.5, 7.88, 20, 150, 476.04, 50, 157.5, 100, 10, 100, 20, 100, 3, 100, 0, 100, 97.65, 100, 1.57, 0, 0, 0, 289.72, 'hello', 'on', 'on', '', '2021-10-10 13:05:26'),
(5, 0, 2, 3, 0, 2, 1, 0, 1, '', 'Mark Taylor', 0, '', '2021-10-13 13:37:00', '1970-01-01 00:00:00', 'Tour', 'Confirmed', 'Falak Sher', 'Sedan (B145)', '', '', 'Arlington, Virginia', 'Baltimore, Maryland', 'Virginia Beach (, , Virginia Beach, Virginia 23450', 'Virginia State Capitol (1000 Bank St, , Richmond, Virginia 23218', '', '', 'Hourly', 70, 1, 0, 70, 30, 0, 50, 30, 90, 0, 30, 90, 90, 190, 'Early', 0, 0, 0, 'Cash', 3, 0, 20, 38, 0.5, 0.95, 0.3, 0.57, 0, 0, 2.5, 4.75, 5, 0, 242.27, 50, 102.5, 92, 0, 91, 0, 93, 2.79, 94, 0, 100, 41, 95.5, 0.97, 1.5, 3.08, 0, 150.34, '', '', 'on', '', '2021-10-12 16:34:52'),
(6, 0, 1, 1, 0, 1, 1, 0, 1, '', 'John Doe', 0, '', '2021-10-13 00:51:00', '1970-01-01 00:00:00', '', 'Confirmed', 'Saad Iqbaal', 'Sedan (B145)', '', '', 'Arlington, Virginia', 'Baltimore, Maryland', 'Virginia Aquarium & Marine Science Center (717 General Booth Blvd, , Virginia Beach, Virginia 23451', 'Virginia Museum of Fine Arts (200 N Arthur Ashe Blvd, , Richmond, Virginia 23220', '', '', 'Zone', 55, 0, 0, 0, 30, 0, 0, 0, 60, 0, 0, 0, 90, 90, '', 0, 0, 0, '', 3, 0, 0, 0, 0, 0, 0, 0, 5, 0, 2.5, 0, 0, 0, 93, 40, 36, 50, 0, 100, 0, 100, 3, 100, 0, 100, 0, 100, 0, 4, 3.6, 0, 42.6, '', '', '', '', '2021-10-12 16:40:20'),
(1001, 0, 2, 2, 0, 2, 1, 0, 1, '', 'David Joseph', 0, '', '2021-10-15 11:25:00', '1970-01-01 00:00:00', 'Tour', 'Confirmed', 'Falak Sher', 'Sedan (B145)', '', '', 'Arlington, Virginia', 'Baltimore, Maryland', 'Shenandoah National Park - Virginia (3655 US Highway 211, , East Luray, Virginia 22835', 'Virginia Beach (, , Virginia Beach, Virginia 23450', '', '', 'Hourly', 55, 3, 15, 220, 30, 1, 0, 30, 60, 2, 25, 180, 90, 430, 'Early', 0, 0, 0, 'Cash', 3, 0, 20, 86, 1.2, 5.16, 1.1, 4.73, 0, 0, 2.5, 10.75, 0, 0, 539.64, 50.1, 45.09, 0, 0, 0, 0, 0, 0, 0, 0, 100, 18, 0, 0, 0, 0, 0, 63.09, '', '', '', '', '2021-10-14 10:08:12'),
(1002, 1001, 3, 3, 0, 1, 2, 0, 1, '', 'Mark Taylor', 0, '', '2021-10-27 22:00:00', '1970-01-01 00:00:00', 'Tour', 'Confirmed', 'Saad Iqbaal', 'SUV (A1234)', '', '', 'Arlington, Virginia', 'Baltimore, Maryland', 'Shenandoah National Park - Virginia (3655 US Highway 211, , East Luray, Virginia 22835', 'Virginia State Capitol (1000 Bank St, , Richmond, Virginia 23218', 'Some routing notes', '', 'Zone', 70, 4, 0, 280, 40, 0, 0, 0, 90, 1, 30, 180, 108, 108, 'Early', 0, 1, 20, 'Cash', 10, 3.5, 20, 21.6, 0.5, 0.54, 0.3, 0.32, 8, 8.64, 2.5, 2.7, 9.75, 170, 167.77, 40, 36, 0, 0, 0, 0, 0, 0, 0, 0, 100, 18, 0, 0, 0, 0, 0, 54, '', 'on', 'on', '', '2021-10-14 14:26:37'),
(1003, 0, 0, 2, 4, 2, 1, 0, 1, '', 'David Joseph', 0, 'Tiffany Joseph', '2021-10-20 14:40:00', '2021-10-16 01:00:00', 'Tour', 'Confirmed', 'Falak Sher', 'Sedan (B145)', '', '', 'Arlington, Virginia', 'Baltimore, Maryland', 'Virginia Beach (, , Virginia Beach, Virginia 23450', 'Virginia Museum of Fine Arts (200 N Arthur Ashe Blvd, , Richmond, Virginia 23220', '', '', 'Hourly', 55, 4, 0, 220, 30, 0, 0, 0, 60, 0, 0, 0, 90, 220, 'Early', 0, 0, 0, 'Cash', 3, 0, 20, 44, 1.2, 2.64, 1.1, 2.42, 0, 0, 2.5, 5.5, 0, 0, 277.56, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 'on', '', '', '2021-10-16 12:34:52'),
(1004, 0, 0, 4, 0, 1, 1, 0, 1, 'AB39458', 'Allen Donald', 1, '', '2021-10-20 17:20:00', '2021-10-18 01:00:00', '', 'Confirmed', 'Saad Iqbaal', 'Sedan (B145)', 'United Airlines', '1750', 'Arlington, Virginia', 'Baltimore, Maryland', 'Shenandoah National Park - Virginia (3655 US Highway 211, , East Luray, Virginia 22835', 'Virginia State Capitol (1000 Bank St, , Richmond, Virginia 23218', '', '', 'Zone', 55, 0, 0, 0, 30, 0, 0, 0, 60, 0, 0, 0, 90, 90, '', 0, 0, 0, '', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 93, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', '2021-10-18 02:19:53'),
(1005, 0, 0, 5, 0, 2, 1, 0, 1, '', 'Julia Roberts', 1, '', '2021-10-20 12:45:00', '2021-10-18 01:00:00', '', 'Dispatched', 'Falak Sher', 'Sedan (B145)', '', '', 'Arlington, Virginia', 'Baltimore, Maryland', 'Virginia Aquarium & Marine Science Center (717 General Booth Blvd, , Virginia Beach, Virginia 23451', 'Virginia State Capitol (1000 Bank St, , Richmond, Virginia 23218', 's', '', 'Flat', 55, 0, 0, 0, 30, 0, 0, 0, 60, 0, 0, 0, 90, 0, 'Early', 0, 0, 0, 'Cash', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', '2021-10-18 02:42:48'),
(1006, 1, 0, 5, 0, 2, 1, 1, 1, '', 'Julia Roberts', 1, '', '2021-10-20 12:45:00', '2021-10-18 01:00:00', 'Tour', 'Dispatched', 'Falak Sher', 'B145', 'United Airlines', '', 'Arlington, Virginia', 'Baltimore, Maryland', 'Virginia Beach (, , Virginia Beach, Virginia 23450', 'Virginia State Capitol (1000 Bank St, , Richmond, Virginia 23218', '', '', 'Zone', 70, 0, 0, 0, 40, 0, 0, 0, 90, 0, 0, 0, 90, 90, 'Early', 0, 0, 0, 'Cash', 3, 0, 20, 18, 1.2, 1.08, 1.1, 0.99, 0.1, 0.09, 2.5, 2.25, 0, 0, 115.23, 50, 45, 0, 0, 0, 0, 0, 0, 0, 0, 100, 18, 0, 0, 0, 0, 0, 63, '', 'on', 'on', '', '2021-10-18 18:41:47'),
(1007, 1003, 0, 5, 3, 2, 1, 3, 1, '', 'Julia Roberts', 1, 'Julia Doe', '2021-10-18 09:00:00', '2021-10-23 01:00:00', 'Tour', 'Confirmed', 'Falak Sher', 'Sedan (B145)', 'Delta Airlines', '3855', 'Arlington, Virginia', 'Baltimore, Maryland', '4321 Some Road, Woodbridge, VA\r\nVirginia Aquarium & Marine Science Center (717 General Booth Blvd, , Virginia Beach, Virginia 23451', '4321 Some Road, Woodbridge, VA\r\nSteven F. Udvar-Hazy Center (14390 Air and Space Museum Pkwy, , Chantilly, Virginia 20151', '', '', 'Zone', 55, 0, 0, 0, 30, 0, 0, 0, 60, 0, 0, 0, 90, 90, 'Early', 0, 0, 0, 'Cash', 3, 0, 20, 18, 1.2, 1.08, 1.1, 0.99, 0, 0, 2.5, 2.25, 5, 0, 120.32, 50, 45, 0, 0, 0, 0, 0, 0, 0, 0, 100, 18, 0, 0, 0, 0, 0, 63, '', 'on', 'on', '', '2021-10-23 13:58:21'),
(1008, 0, 0, 5, 3, 2, 2, 3, 1, '', 'Julia Roberts', 1, 'Julia Doe', '2021-10-18 09:00:00', '2021-10-23 01:00:00', 'Tour', 'Confirmed', 'Falak Sher', 'SUV (A1234)', 'Delta Airlines', '3855', 'Arlington, Virginia', 'Baltimore, Maryland', '4321 Some Road, Woodbridge, VA', '1234 Some Street, Dale City, VA', '', '', 'Zone', 70, 0, 0, 0, 40, 0, 0, 0, 90, 0, 0, 0, 108, 108, 'Early', 0, 0, 0, 'Cash', 3, 0, 20, 21.6, 1.2, 1.3, 1.1, 1.19, 0, 0, 2.5, 2.7, 0, 0, 137.78, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', '2021-10-23 17:28:15'),
(1009, 0, 0, 4, 0, 1, 2, 0, 1, 'AB39457', 'Allen Donald', 1, '', '2021-10-29 17:20:00', '2021-10-18 01:00:00', 'Tour', 'Quoted', 'Saad Iqbaal', 'SUV (A1234)', 'United Airlines', '1750', 'Arlington, Virginia', 'Baltimore, Maryland', 'Shenandoah National Park - Virginia (3655 US Highway 211, , East Luray, Virginia 22835', 'Virginia State Capitol (1000 Bank St, , Richmond, Virginia 23218', '', '', 'Zone', 70, 3, 0, 210, 40, 2, 0, 80, 90, 1, 0, 90, 90, 90, 'Early', 0, 0, 0, 'Cash', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 93, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', '2021-10-23 17:37:10'),
(1010, 0, 0, 2, 4, 1, 1, 0, 1, '', 'David Joseph', 1, 'Tiffany Joseph', '2021-10-26 12:00:00', '2021-10-25 01:00:00', 'Tour', 'Confirmed', 'Saad Iqbaal', 'Sedan (B145)', '', '', 'Arlington, Virginia', 'Baltimore, Maryland', 'John Doe Office (123 Almond Street, , Fairfax, VA 221445', 'Home (1234 David Street, , Dale City, Virginia 22192', 'trip notes', '', 'Hourly', 45, 3, 0, 135, 0, 0, 0, 0, 0, 0, 0, 0, 90, 135, 'Early', 0, 0, 0, 'Cash', 3, 0, 20, 27, 1.2, 1.62, 1.1, 1.49, 0.1, 0.14, 2.5, 3.38, 0, 0, 171.35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', '2021-10-25 13:49:12');

-- --------------------------------------------------------

--
-- Table structure for table `trip_extra_charges`
--

CREATE TABLE `trip_extra_charges` (
  `key_trip_extra_charges` int(10) UNSIGNED NOT NULL,
  `key_trips` int(10) UNSIGNED NOT NULL,
  `category` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `amount` float DEFAULT '0',
  `notes` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `trip_extra_charges`
--

INSERT INTO `trip_extra_charges` (`key_trip_extra_charges`, `key_trips`, `category`, `amount`, `notes`, `entry_date_time`) VALUES
(5, 4, 'Baby seat', 20, '', '2021-10-10 18:14:38'),
(6, 4, 'Coffee', 0, '', '2021-10-10 18:16:20'),
(7, 3, 'Coffee', 5.4, '', '2021-10-10 18:21:38'),
(8, 2, 'Bottled water', 5, '', '2021-10-10 18:24:30'),
(9, 4, 'Bottled water', 0, '', '2021-10-11 02:06:55'),
(11, 5, 'Bottled water', 5, '', '2021-10-12 16:35:09'),
(12, 1, 'Bottled water', 5, '', '2021-10-13 16:11:22'),
(13, 4, 'Coffee', 0, '', '2021-10-16 13:59:58'),
(14, 1007, 'Bottled water', 5, '', '2021-10-27 10:31:56'),
(15, 1002, 'Bottled water', 4.5, '', '2021-10-27 17:43:04'),
(16, 1002, 'Coffee', 5.25, '', '2021-10-27 17:46:13');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `key_vehicles` int(10) UNSIGNED NOT NULL,
  `key_settings_insurance_company_values` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `fleet_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vehicle_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vin_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `year_made` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `model` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `max_seats` int(10) NOT NULL DEFAULT '0',
  `color` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `insurance_company` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `insurance_expiry_date` date DEFAULT NULL,
  `image_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zone_rate_percent` float NOT NULL DEFAULT '0',
  `hourly_regular_rate` float NOT NULL DEFAULT '0',
  `hourly_wait_rate` float NOT NULL DEFAULT '0',
  `hourly_overtime_rate` float NOT NULL DEFAULT '0',
  `notes` varchar(3000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `active_status` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`key_vehicles`, `key_settings_insurance_company_values`, `fleet_number`, `vehicle_type`, `tag`, `vin_number`, `year_made`, `model`, `max_seats`, `color`, `insurance_company`, `insurance_expiry_date`, `image_url`, `zone_rate_percent`, `hourly_regular_rate`, `hourly_wait_rate`, `hourly_overtime_rate`, `notes`, `active_status`, `entry_date_time`) VALUES
(1, 1, 'B145', 'Sedan', 'NW-1234', '92384902890809423', '2020', '', 3, '', 'Nationwide Insurance Company', '1970-01-01', '', 100, 55, 30, 60, '', 'on', '2021-10-07 09:54:22'),
(2, 1, 'A1234', 'SUV', '', '', '', '', 0, '', 'Nationwide Insurance Company', '2022-06-16', '', 120, 70, 40, 90, '', 'on', '2021-10-18 18:37:05');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles_maintenance`
--

CREATE TABLE `vehicles_maintenance` (
  `key_vehicles_maintenance` int(10) UNSIGNED NOT NULL,
  `key_vehicles` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `repair_date` date DEFAULT NULL,
  `repair_description` varchar(3000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `workshop_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `labor_cost` float NOT NULL DEFAULT '0',
  `parts_cost` float NOT NULL DEFAULT '0',
  `warranty_description` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `warranty_expiration` date DEFAULT NULL,
  `entry_date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vehicles_maintenance`
--

INSERT INTO `vehicles_maintenance` (`key_vehicles_maintenance`, `key_vehicles`, `repair_date`, `repair_description`, `workshop_name`, `labor_cost`, `parts_cost`, `warranty_description`, `warranty_expiration`, `entry_date_time`) VALUES
(1, 1, '2021-09-21', '', 'Lucky Auto Repair', 58, 180, 'yes', '2021-11-24', '2021-09-27 17:07:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer_address_book`
--
ALTER TABLE `customer_address_book`
  ADD PRIMARY KEY (`key_customer_address_book`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `key_customer_passengers` (`key_customer_passengers`);
ALTER TABLE `customer_address_book` ADD FULLTEXT KEY `phpblink_fulltext` (`title`,`category`,`city`,`zip_code`);

--
-- Indexes for table `customer_billing_contacts`
--
ALTER TABLE `customer_billing_contacts`
  ADD PRIMARY KEY (`key_customer_billing_contacts`),
  ADD UNIQUE KEY `card_number` (`card_number`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `customer_billing_contacts` ADD FULLTEXT KEY `customer_billing_contacts_fulltext` (`contact_name`,`card_type`,`name_on_card`);

--
-- Indexes for table `customer_companies`
--
ALTER TABLE `customer_companies`
  ADD PRIMARY KEY (`key_customer_companies`),
  ADD UNIQUE KEY `company_name` (`company_name`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `customer_companies` ADD FULLTEXT KEY `customer_companies_fulltext` (`company_name`,`address1`,`state`,`zip_code`,`country`);

--
-- Indexes for table `customer_contacts`
--
ALTER TABLE `customer_contacts`
  ADD PRIMARY KEY (`key_customer_contacts`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `key_customer_companies` (`key_customer_companies`);
ALTER TABLE `customer_contacts` ADD FULLTEXT KEY `customer_contacts_fulltext` (`company_name`,`first_name`,`last_name`,`address1`,`address2`,`city`,`state`,`zip_code`,`country`,`email`);

--
-- Indexes for table `customer_invoices`
--
ALTER TABLE `customer_invoices`
  ADD PRIMARY KEY (`key_customer_invoices`),
  ADD KEY `key_customer_passengers` (`key_customer_passengers`),
  ADD KEY `end_date` (`end_date`),
  ADD KEY `due_date` (`due_date`),
  ADD KEY `payment_method` (`payment_method`);

--
-- Indexes for table `customer_passengers`
--
ALTER TABLE `customer_passengers`
  ADD PRIMARY KEY (`key_customer_passengers`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `key_customer_companies` (`key_customer_companies`),
  ADD KEY `key_customer_rate_packages` (`key_customer_rate_packages`),
  ADD KEY `key_customer_billing_contacts` (`key_customer_billing_contacts`);
ALTER TABLE `customer_passengers` ADD FULLTEXT KEY `customer_passengers_fulltext` (`first_name`,`last_name`,`address1`,`city`,`state`,`country`,`zip_code`,`email`,`ad_source`);

--
-- Indexes for table `customer_rate_packages`
--
ALTER TABLE `customer_rate_packages`
  ADD PRIMARY KEY (`key_customer_rate_packages`),
  ADD UNIQUE KEY `package_name` (`package_name`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `customer_rate_packages` ADD FULLTEXT KEY `customer_rate_packages_fulltext` (`package_name`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`key_drivers`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `key_vehicles` (`key_vehicles`);
ALTER TABLE `drivers` ADD FULLTEXT KEY `drivers_fulltext` (`first_name`,`last_name`,`contract_type`,`city`,`state`,`zip_code`,`fleet_number`);

--
-- Indexes for table `driver_payroll`
--
ALTER TABLE `driver_payroll`
  ADD PRIMARY KEY (`key_driver_payroll`),
  ADD KEY `end_date` (`end_date`),
  ADD KEY `due_date` (`due_date`),
  ADD KEY `payment_method` (`payment_method`),
  ADD KEY `key_drivers` (`key_drivers`);
ALTER TABLE `driver_payroll` ADD FULLTEXT KEY `driver_payroll_fulltext` (`payment_method`);

--
-- Indexes for table `landmarks`
--
ALTER TABLE `landmarks`
  ADD PRIMARY KEY (`key_landmarks`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `landmarks` ADD FULLTEXT KEY `landmarks_fulltext` (`title`,`category`,`city`,`zip_code`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`key_logs`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `log_datetime` (`log_datetime`);
ALTER TABLE `logs` ADD FULLTEXT KEY `logs_fulltext` (`log_type`,`action_performed`);

--
-- Indexes for table `rates_zones`
--
ALTER TABLE `rates_zones`
  ADD PRIMARY KEY (`key_rates_zones`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `rates_zones` ADD FULLTEXT KEY `rates_zones_fulltext` (`from_city`,`to_city`);

--
-- Indexes for table `settings_ad_source_values`
--
ALTER TABLE `settings_ad_source_values`
  ADD PRIMARY KEY (`key_settings_ad_source_values`),
  ADD UNIQUE KEY `ad_source` (`ad_source`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_ad_source_values` ADD FULLTEXT KEY `settings_ad_source_values_fulltext` (`ad_source`);

--
-- Indexes for table `settings_airline_values`
--
ALTER TABLE `settings_airline_values`
  ADD PRIMARY KEY (`key_settings_airline_values`),
  ADD UNIQUE KEY `airline` (`airline`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_airline_values` ADD FULLTEXT KEY `settings_airline_values_fulltext` (`airline`);

--
-- Indexes for table `settings_company`
--
ALTER TABLE `settings_company`
  ADD PRIMARY KEY (`key_settings_company`),
  ADD KEY `entry_date_time` (`entry_date_time`);

--
-- Indexes for table `settings_country_values`
--
ALTER TABLE `settings_country_values`
  ADD PRIMARY KEY (`key_settings_country_values`),
  ADD UNIQUE KEY `country` (`country`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_country_values` ADD FULLTEXT KEY `settings_country_values_fulltext` (`country`,`country_code`);

--
-- Indexes for table `settings_dispatch_area_values`
--
ALTER TABLE `settings_dispatch_area_values`
  ADD PRIMARY KEY (`key_settings_dispatch_area_values`),
  ADD UNIQUE KEY `dispatch_area` (`dispatch_area`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_dispatch_area_values` ADD FULLTEXT KEY `settings_dispatch_area_values_fulltext` (`dispatch_area`);

--
-- Indexes for table `settings_email_configuration`
--
ALTER TABLE `settings_email_configuration`
  ADD PRIMARY KEY (`key_settings_email_configuration`),
  ADD KEY `entry_date_time` (`entry_date_time`);

--
-- Indexes for table `settings_extra_charges_values`
--
ALTER TABLE `settings_extra_charges_values`
  ADD PRIMARY KEY (`key_settings_extra_charges_values`),
  ADD UNIQUE KEY `category` (`category`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_extra_charges_values` ADD FULLTEXT KEY `settings_extra_charges_values_fulltext` (`category`);

--
-- Indexes for table `settings_insurance_company_values`
--
ALTER TABLE `settings_insurance_company_values`
  ADD PRIMARY KEY (`key_settings_insurance_company_values`),
  ADD UNIQUE KEY `insurance_company` (`insurance_company`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_insurance_company_values` ADD FULLTEXT KEY `settings_insurance_company_values_fulltext` (`insurance_company`);

--
-- Indexes for table `settings_landmark_values`
--
ALTER TABLE `settings_landmark_values`
  ADD PRIMARY KEY (`key_settings_landmark_values`),
  ADD UNIQUE KEY `category` (`category`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_landmark_values` ADD FULLTEXT KEY `settings_landmark_values_fulltext` (`category`);

--
-- Indexes for table `settings_offtime_type_values`
--
ALTER TABLE `settings_offtime_type_values`
  ADD PRIMARY KEY (`key_settings_offtime_type_values`),
  ADD UNIQUE KEY `offtime_type` (`offtime_type`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_offtime_type_values` ADD FULLTEXT KEY `settings_offtime_type_values_fulltext` (`offtime_type`);

--
-- Indexes for table `settings_payment_card_type_values`
--
ALTER TABLE `settings_payment_card_type_values`
  ADD PRIMARY KEY (`key_settings_payment_card_type_values`),
  ADD UNIQUE KEY `payment_card_type` (`payment_card_type`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_payment_card_type_values` ADD FULLTEXT KEY `settings_payment_card_type_values_fulltext` (`payment_card_type`);

--
-- Indexes for table `settings_payment_method_values`
--
ALTER TABLE `settings_payment_method_values`
  ADD PRIMARY KEY (`key_settings_payment_method_values`),
  ADD UNIQUE KEY `payment_method` (`payment_method`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_payment_method_values` ADD FULLTEXT KEY `settings_payment_method_values_fulltext` (`payment_method`);

--
-- Indexes for table `settings_state_values`
--
ALTER TABLE `settings_state_values`
  ADD PRIMARY KEY (`key_settings_state_values`),
  ADD UNIQUE KEY `state` (`state`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_state_values` ADD FULLTEXT KEY `settings_state_values_fulltext` (`state`,`state_code`);

--
-- Indexes for table `settings_toll_type_values`
--
ALTER TABLE `settings_toll_type_values`
  ADD PRIMARY KEY (`key_settings_toll_type_values`),
  ADD UNIQUE KEY `toll_type` (`toll_type`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_toll_type_values` ADD FULLTEXT KEY `settings_toll_type_values_fulltext` (`toll_type`);

--
-- Indexes for table `settings_trips`
--
ALTER TABLE `settings_trips`
  ADD PRIMARY KEY (`key_settings_trips`),
  ADD KEY `entry_date_time` (`entry_date_time`);

--
-- Indexes for table `settings_trip_status_values`
--
ALTER TABLE `settings_trip_status_values`
  ADD PRIMARY KEY (`key_settings_trip_status_values`),
  ADD UNIQUE KEY `trip_status` (`trip_status`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_trip_status_values` ADD FULLTEXT KEY `settings_trip_status_values_fulltext` (`trip_status`);

--
-- Indexes for table `settings_trip_type_values`
--
ALTER TABLE `settings_trip_type_values`
  ADD PRIMARY KEY (`key_settings_trip_type_values`),
  ADD UNIQUE KEY `trip_type` (`trip_type`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_trip_type_values` ADD FULLTEXT KEY `settings_trip_type_values_fulltext` (`trip_type`);

--
-- Indexes for table `settings_vehicle_model_values`
--
ALTER TABLE `settings_vehicle_model_values`
  ADD PRIMARY KEY (`key_settings_vehicle_model_values`),
  ADD UNIQUE KEY `vehicle_model` (`vehicle_model`),
  ADD KEY `entry_date_time` (`entry_date_time`);

--
-- Indexes for table `settings_vehicle_type_values`
--
ALTER TABLE `settings_vehicle_type_values`
  ADD PRIMARY KEY (`key_settings_vehicle_type_values`),
  ADD UNIQUE KEY `vehicle_type` (`vehicle_type`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_vehicle_type_values` ADD FULLTEXT KEY `settings_vehicle_type_values_fulltext` (`vehicle_type`);

--
-- Indexes for table `settings_workshop_name_values`
--
ALTER TABLE `settings_workshop_name_values`
  ADD PRIMARY KEY (`key_settings_workshop_name_values`),
  ADD UNIQUE KEY `workshop_name` (`workshop_name`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `settings_workshop_name_values` ADD FULLTEXT KEY `settings_workshop_name_values_fulltext` (`workshop_name`,`city`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`key_staff`),
  ADD KEY `entry_date_time` (`entry_date_time`);
ALTER TABLE `staff` ADD FULLTEXT KEY `staff_fulltext` (`designation`,`first_name`,`last_name`);

--
-- Indexes for table `trips`
--
ALTER TABLE `trips`
  ADD PRIMARY KEY (`key_trips`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `key_customer_invoices` (`key_customer_invoices`),
  ADD KEY `key_driver_payroll` (`key_driver_payroll`),
  ADD KEY `key_customer_passengers` (`key_customer_passengers`),
  ADD KEY `key_customer_contacts` (`key_customer_contacts`),
  ADD KEY `key_drivers` (`key_drivers`),
  ADD KEY `key_vehicles` (`key_vehicles`),
  ADD KEY `key_rates_zones` (`key_rates_zones`),
  ADD KEY `pickup_datetime` (`pickup_datetime`),
  ADD KEY `key_settings_airline_values` (`key_settings_airline_values`);
ALTER TABLE `trips` ADD FULLTEXT KEY `trips_fulltext` (`passenger_name`,`reference_number`,`reserved_by`,`trip_type`,`driver_name`,`vehicle`,`airline`,`flight_number`,`zone_from`,`zone_to`);

--
-- Indexes for table `trip_extra_charges`
--
ALTER TABLE `trip_extra_charges`
  ADD PRIMARY KEY (`key_trip_extra_charges`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `key_trips` (`key_trips`);
ALTER TABLE `trip_extra_charges` ADD FULLTEXT KEY `phpblink_fulltext` (`category`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`key_vehicles`),
  ADD UNIQUE KEY `fleet_number` (`fleet_number`),
  ADD UNIQUE KEY `vin_number` (`vin_number`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `key_insurance_company_values` (`key_settings_insurance_company_values`);
ALTER TABLE `vehicles` ADD FULLTEXT KEY `vehicles_fulltext` (`fleet_number`,`vehicle_type`,`tag`,`vin_number`,`year_made`,`model`,`color`,`notes`);

--
-- Indexes for table `vehicles_maintenance`
--
ALTER TABLE `vehicles_maintenance`
  ADD PRIMARY KEY (`key_vehicles_maintenance`),
  ADD KEY `entry_date_time` (`entry_date_time`),
  ADD KEY `key_vehicles` (`key_vehicles`),
  ADD KEY `repair_date` (`repair_date`);
ALTER TABLE `vehicles_maintenance` ADD FULLTEXT KEY `vehicles_maintenance_fulltext` (`repair_description`,`workshop_name`,`warranty_description`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer_address_book`
--
ALTER TABLE `customer_address_book`
  MODIFY `key_customer_address_book` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `customer_billing_contacts`
--
ALTER TABLE `customer_billing_contacts`
  MODIFY `key_customer_billing_contacts` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `customer_companies`
--
ALTER TABLE `customer_companies`
  MODIFY `key_customer_companies` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `customer_contacts`
--
ALTER TABLE `customer_contacts`
  MODIFY `key_customer_contacts` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `customer_invoices`
--
ALTER TABLE `customer_invoices`
  MODIFY `key_customer_invoices` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1005;
--
-- AUTO_INCREMENT for table `customer_passengers`
--
ALTER TABLE `customer_passengers`
  MODIFY `key_customer_passengers` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `customer_rate_packages`
--
ALTER TABLE `customer_rate_packages`
  MODIFY `key_customer_rate_packages` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `key_drivers` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `driver_payroll`
--
ALTER TABLE `driver_payroll`
  MODIFY `key_driver_payroll` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `landmarks`
--
ALTER TABLE `landmarks`
  MODIFY `key_landmarks` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `key_logs` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rates_zones`
--
ALTER TABLE `rates_zones`
  MODIFY `key_rates_zones` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `settings_ad_source_values`
--
ALTER TABLE `settings_ad_source_values`
  MODIFY `key_settings_ad_source_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings_airline_values`
--
ALTER TABLE `settings_airline_values`
  MODIFY `key_settings_airline_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `settings_company`
--
ALTER TABLE `settings_company`
  MODIFY `key_settings_company` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `settings_country_values`
--
ALTER TABLE `settings_country_values`
  MODIFY `key_settings_country_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `settings_dispatch_area_values`
--
ALTER TABLE `settings_dispatch_area_values`
  MODIFY `key_settings_dispatch_area_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings_email_configuration`
--
ALTER TABLE `settings_email_configuration`
  MODIFY `key_settings_email_configuration` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `settings_extra_charges_values`
--
ALTER TABLE `settings_extra_charges_values`
  MODIFY `key_settings_extra_charges_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `settings_insurance_company_values`
--
ALTER TABLE `settings_insurance_company_values`
  MODIFY `key_settings_insurance_company_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `settings_landmark_values`
--
ALTER TABLE `settings_landmark_values`
  MODIFY `key_settings_landmark_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings_offtime_type_values`
--
ALTER TABLE `settings_offtime_type_values`
  MODIFY `key_settings_offtime_type_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `settings_payment_card_type_values`
--
ALTER TABLE `settings_payment_card_type_values`
  MODIFY `key_settings_payment_card_type_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `settings_payment_method_values`
--
ALTER TABLE `settings_payment_method_values`
  MODIFY `key_settings_payment_method_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `settings_state_values`
--
ALTER TABLE `settings_state_values`
  MODIFY `key_settings_state_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `settings_toll_type_values`
--
ALTER TABLE `settings_toll_type_values`
  MODIFY `key_settings_toll_type_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `settings_trips`
--
ALTER TABLE `settings_trips`
  MODIFY `key_settings_trips` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `settings_trip_status_values`
--
ALTER TABLE `settings_trip_status_values`
  MODIFY `key_settings_trip_status_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `settings_trip_type_values`
--
ALTER TABLE `settings_trip_type_values`
  MODIFY `key_settings_trip_type_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `settings_vehicle_model_values`
--
ALTER TABLE `settings_vehicle_model_values`
  MODIFY `key_settings_vehicle_model_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings_vehicle_type_values`
--
ALTER TABLE `settings_vehicle_type_values`
  MODIFY `key_settings_vehicle_type_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `settings_workshop_name_values`
--
ALTER TABLE `settings_workshop_name_values`
  MODIFY `key_settings_workshop_name_values` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `key_staff` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `trips`
--
ALTER TABLE `trips`
  MODIFY `key_trips` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1011;
--
-- AUTO_INCREMENT for table `trip_extra_charges`
--
ALTER TABLE `trip_extra_charges`
  MODIFY `key_trip_extra_charges` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `key_vehicles` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `vehicles_maintenance`
--
ALTER TABLE `vehicles_maintenance`
  MODIFY `key_vehicles_maintenance` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer_address_book`
--
ALTER TABLE `customer_address_book`
  ADD CONSTRAINT `customer_address_book_ibfk_1` FOREIGN KEY (`key_customer_passengers`) REFERENCES `customer_passengers` (`key_customer_passengers`) ON DELETE CASCADE;

--
-- Constraints for table `trip_extra_charges`
--
ALTER TABLE `trip_extra_charges`
  ADD CONSTRAINT `trip_extra_charges_ibfk_1` FOREIGN KEY (`key_trips`) REFERENCES `trips` (`key_trips`) ON DELETE CASCADE;

--
-- Constraints for table `vehicles_maintenance`
--
ALTER TABLE `vehicles_maintenance`
  ADD CONSTRAINT `vehicles_maintenance_ibfk_1` FOREIGN KEY (`key_vehicles`) REFERENCES `vehicles` (`key_vehicles`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
