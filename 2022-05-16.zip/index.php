<?php 
include('php/_code.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<?php include('php/_head.php'); ?>
</head>
<body id='page-index'>
	<?php include('php/_header.php'); ?>
</body>
</html>
