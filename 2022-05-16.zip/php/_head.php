<meta name='viewport' content='width=device-width, initial-scale=1'>		
	<meta charset='utf-8'>
	<link rel='stylesheet' href='css/styles.css?v=1'>
	<script src='js/_scripts.js?v=1'></script>
